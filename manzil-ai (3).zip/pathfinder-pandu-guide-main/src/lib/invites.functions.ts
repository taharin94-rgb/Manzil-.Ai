import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GenInput = z.object({ intended_role: z.enum(["parent", "school"]) });

function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 8; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export const generateInviteCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => GenInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    for (let attempt = 0; attempt < 5; attempt++) {
      const code = makeCode();
      const { data: row, error } = await supabase
        .from("invite_codes")
        .insert({ code, student_id: userId, intended_role: data.intended_role })
        .select("code")
        .single();
      if (!error) return { code: row.code };
    }
    throw new Error("Could not generate invite code, please retry.");
  });

const RedeemInput = z.object({ code: z.string().trim().min(4).max(16) });

export const redeemInviteCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => RedeemInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    void supabase;
    const { data: invite } = await supabaseAdmin
      .from("invite_codes")
      .select("id, student_id, intended_role, used_by")
      .eq("code", data.code.toUpperCase())
      .maybeSingle();
    if (!invite) throw new Error("Invalid code");
    if (invite.used_by) throw new Error("This code has already been used");
    if (invite.student_id === userId) throw new Error("You can't redeem your own code");


    // Assign role (admin so we can insert role of intended_role)
    const { error: roleErr } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId, role: invite.intended_role }, { onConflict: "user_id,role" });
    if (roleErr) throw new Error(roleErr.message);

    // Create link
    const linkErr = invite.intended_role === "parent"
      ? (await supabaseAdmin.from("parent_students").upsert({ parent_id: userId, student_id: invite.student_id }, { onConflict: "parent_id,student_id" })).error
      : (await supabaseAdmin.from("school_students").upsert({ school_id: userId, student_id: invite.student_id }, { onConflict: "school_id,student_id" })).error;
    if (linkErr) throw new Error(linkErr.message);

    // Mark used
    await supabaseAdmin.from("invite_codes").update({ used_by: userId, used_at: new Date().toISOString() }).eq("id", invite.id);

    return { role: invite.intended_role, student_id: invite.student_id };
  });
