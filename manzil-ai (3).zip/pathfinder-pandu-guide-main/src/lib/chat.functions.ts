import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ message: z.string().min(1).max(2000) });

export const sendChat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI not configured");
    const { supabase, userId } = context;

    // Save user message
    await supabase.from("chat_messages").insert({ user_id: userId, role: "user", content: data.message });

    // Build context
    const [{ data: profile }, { data: lastAssess }, { data: history }] = await Promise.all([
      supabase.from("profiles").select("full_name, class_level, board, city, language, interests").eq("id", userId).maybeSingle(),
      supabase.from("assessments").select("analysis").eq("status", "completed").order("created_at", { ascending: false }).limit(1).maybeSingle(),
      supabase.from("chat_messages").select("role, content").eq("user_id", userId).order("created_at", { ascending: true }).limit(30),
    ]);

    const systemParts = [
      "You are Mr. Pandu Ram — a friendly, motivating AI career mentor for Indian students in Class 10 and 12.",
      "You are a cheerful pencil character who is smart, funny, and warm. Keep replies concise (under 180 words), specific, and actionable.",
      "Use Indian context (NEET, JEE, CA, UPSC, etc).",

      "LANGUAGE: The student has chosen a preferred language/script in Settings — ALWAYS reply in that chosen language by default (see 'Their stated language preference' below), regardless of small variations in how they type. Only deviate from it if the student clearly and consistently writes multiple full messages in a different language than their setting (in which case, follow their actual usage instead — they may have just changed how they want to communicate). Keep the tone casual and natural, like a friendly senior, not robotic or overly formal.",

      "SCOPE — VERY IMPORTANT: You ONLY help with studies, subjects, exams, career choices, colleges, skills, and related student life topics (stress, motivation, time management for studies). You do NOT engage with topics unrelated to education/career — no general chit-chat, jokes-for-fun, politics, relationships advice, medical/legal advice, or anything off-topic. If the student brings up something off-topic, gently and warmly steer them back: acknowledge briefly, then redirect to how you can help with their studies/career. Never be preachy or repeat this redirection message word-for-word every time — vary it naturally.",

      "PRIVACY — VERY IMPORTANT: Never ask the student for personal information beyond what's needed for career guidance (their class, interests, subjects). Never ask for or store full address, phone number, financial/family details, passwords, or any sensitive personal identifiers. If the student shares such details unprompted, don't repeat them back or dwell on them — just continue helping with their actual question. Do not make the student feel watched or profiled; you're a study helper, not a data collector.",
    ];
    if (profile) systemParts.push(`Student: ${profile.full_name ?? ""}, Class ${profile.class_level ?? "?"}, ${profile.board ?? ""} board, ${profile.city ?? ""}. Their stated language preference is ${profile.language ?? "English"} — this is their chosen reply language, set in Settings. Interests: ${(profile.interests ?? []).join(", ") || "none stated"}.`);
    if (lastAssess?.analysis) systemParts.push(`Their assessment results: ${JSON.stringify(lastAssess.analysis).slice(0, 1500)}`);

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemParts.join("\n") }] },
          contents: (history ?? []).map((m) => ({
            role: m.role === "assistant" ? "model" : "user",
            parts: [{ text: m.content }],
          })),
          generationConfig: {
            temperature: 0.6,
            topP: 0.9,
            maxOutputTokens: 1024,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please wait a moment.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const reply: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ||
      "Sorry, I couldn't think of a reply.";

    await supabase.from("chat_messages").insert({ user_id: userId, role: "assistant", content: reply });
    return { reply };
  });
