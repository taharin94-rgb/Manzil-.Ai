// Small, hand-checked translation dictionary for the app's most visible,
// always-present UI text (bottom navigation). Scoped intentionally — a full
// app-wide translation system (every string on every page) is a much larger
// project; this covers the highest-visibility text safely.

export const NAV_LABELS: Record<string, Record<string, string>> = {
  Home: {
    Hindi: "होम", English: "Home", Hinglish: "Home",
    Marathi: "होम", Tamil: "முகப்பு", Telugu: "హోమ్", Bengali: "হোম",
    Gujarati: "હોમ", Kannada: "ಮುಖಪುಟ", Malayalam: "ഹോം", Punjabi: "ਹੋਮ", Urdu: "ہوم",
  },
  Explore: {
    Hindi: "एक्सप्लोर", English: "Explore", Hinglish: "Explore",
    Marathi: "एक्सप्लोर", Tamil: "ஆராயுங்கள்", Telugu: "అన్వేషించండి", Bengali: "এক্সপ্লোর",
    Gujarati: "એક્સપ્લોર", Kannada: "ಎಕ್ಸ್‌ಪ್ಲೋರ್", Malayalam: "എക്സ്‌പ്ലോർ", Punjabi: "ਐਕਸਪਲੋਰ", Urdu: "دریافت کریں",
  },
  Mentor: {
    Hindi: "मेंटर", English: "Mentor", Hinglish: "Mentor",
    Marathi: "मेंटर", Tamil: "வழிகாட்டி", Telugu: "మెంటర్", Bengali: "মেন্টর",
    Gujarati: "મેન્ટર", Kannada: "ಮಾರ್ಗದರ್ಶಕ", Malayalam: "മെന്റർ", Punjabi: "ਮੈਂਟਰ", Urdu: "رہنما",
  },
  Goals: {
    Hindi: "गोल्स", English: "Goals", Hinglish: "Goals",
    Marathi: "गोल्स", Tamil: "இலக்குகள்", Telugu: "గోల్స్", Bengali: "গোল",
    Gujarati: "ગોલ્સ", Kannada: "ಗುರಿಗಳು", Malayalam: "ലക്ഷ്യങ്ങൾ", Punjabi: "ਟੀਚੇ", Urdu: "اہداف",
  },
  Battle: {
    Hindi: "बैटल", English: "Battle", Hinglish: "Battle",
    Marathi: "बॅटल", Tamil: "போட்டி", Telugu: "బ్యాటిల్", Bengali: "ব্যাটল",
    Gujarati: "બેટલ", Kannada: "ಬ್ಯಾಟಲ್", Malayalam: "ബാറ്റിൽ", Punjabi: "ਬੈਟਲ", Urdu: "مقابلہ",
  },
  Predict: {
    Hindi: "प्रेडिक्ट", English: "Predict", Hinglish: "Predict",
    Marathi: "प्रेडिक्ट", Tamil: "கணிப்பு", Telugu: "ప్రిడిక్ట్", Bengali: "প্রেডিক্ট",
    Gujarati: "પ્રેડિક્ટ", Kannada: "ಭವಿಷ್ಯ", Malayalam: "പ്രവചനം", Punjabi: "ਭਵਿੱਖਬਾਣੀ", Urdu: "پیشگوئی",
  },
  Premium: {
    Hindi: "प्रीमियम", English: "Premium", Hinglish: "Premium",
    Marathi: "प्रीमियम", Tamil: "பிரீமியம்", Telugu: "ప్రీమియం", Bengali: "প্রিমিয়াম",
    Gujarati: "પ્રીમિયમ", Kannada: "ಪ್ರೀಮಿಯಂ", Malayalam: "പ്രീമിയം", Punjabi: "ਪ੍ਰੀਮੀਅਮ", Urdu: "پریمیم",
  },
};

export function navLabel(key: string, lang: string | null | undefined): string {
  return NAV_LABELS[key]?.[lang ?? "English"] ?? NAV_LABELS[key]?.English ?? key;
}
