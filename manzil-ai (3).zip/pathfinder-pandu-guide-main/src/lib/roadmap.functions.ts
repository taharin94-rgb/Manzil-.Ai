import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  careerSlug: z.string().min(1).max(80),
  targetExam: z.string().max(60).optional(),
  targetYear: z.number().int().optional(),
});

export type GeneratedMilestone = { id: string; title: string; detail?: string; done: boolean };
type GeneratedRoadmap = { description: string; milestones: GeneratedMilestone[] };

export const generateRoadmap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");
    const { supabase, userId } = context;

    const [{ data: profile }, { data: lastAssess }, { data: career, error: careerError }] = await Promise.all([
      supabase.from("profiles").select("class_level, board, city, interests, language").eq("id", userId).maybeSingle(),
      supabase.from("assessments").select("analysis").eq("status", "completed").order("created_at", { ascending: false }).limit(1).maybeSingle(),
      supabase.from("careers").select("name, overview, skills, roadmap").eq("slug", data.careerSlug).maybeSingle(),
    ]);
    if (careerError) throw new Error(careerError.message);
    if (!career) throw new Error("Career not found");

    const system = [
      "You are an expert Indian career counsellor creating a deeply detailed, personalized, actionable roadmap for a Class 10/12 student aiming for a specific career.",
      "Tailor every milestone to THIS student's current class, board, and interests where that info is given — don't give generic advice that ignores their starting point.",
      "Produce 9 to 14 milestones, in chronological order from where the student is now until they're established in the career (school subjects -> entrance exams/degree -> specific skills/languages/tools in learning order -> beginner-to-advanced projects -> certifications -> internship prep -> resume/portfolio -> first job -> growth).",
      "Each milestone needs a short, specific 'title' (under 14 words, action-oriented, e.g. 'Clear Class 11 with strong Physics & Maths grades') and a rich 'detail' (2-3 sentences) that, where relevant, names concrete subjects/tools/languages in the right order, specific real free resources (a real YouTube channel, freeCodeCamp/Coursera/Kaggle, etc.), a realistic time estimate for that stage, and — for later milestones — a realistic expected salary range in India at that stage. Never invent fake resource names or certifications.",
      'Respond ONLY as JSON matching: { "description": string, "milestones": [{ "title": string, "detail": string }] }. No markdown, no extra text.',
    ].join("\n");

    const userPrompt = [
      `Career: ${career.name}`,
      career.overview ? `Overview: ${career.overview}` : "",
      career.skills ? `Key skills: ${(career.skills as string[] | null)?.join(", ") ?? ""}` : "",
      career.roadmap ? `Typical steps for this career: ${(career.roadmap as { step: string }[] | null)?.map((r) => r.step).join(" -> ")}` : "",
      data.targetExam ? `Student's target exam preference: ${data.targetExam}` : "",
      data.targetYear ? `Target year to achieve this: ${data.targetYear}` : "",
      profile ? `Student: Class ${profile.class_level ?? "?"}, ${profile.board ?? "?"} board, city: ${profile.city ?? "?"}. Interests: ${(profile.interests ?? []).join(", ") || "none stated"}. Write the roadmap in ${profile.language ?? "English"} (their chosen app language).` : "",
      lastAssess?.analysis ? `Their latest assessment results: ${JSON.stringify(lastAssess.analysis).slice(0, 1200)}` : "",
    ].filter(Boolean).join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.7, maxOutputTokens: 3500, thinkingConfig: { thinkingBudget: 0 } },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let parsed: { description?: string; milestones?: { title?: string; detail?: string }[] };
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("AI returned an unexpected format — please try again.");
    }
    const validMilestones = (parsed.milestones ?? [])
      .filter((m) => typeof m?.title === "string" && m.title.trim())
      .map((m, i) => ({ id: `${Date.now()}-${i}`, title: m.title as string, detail: m.detail, done: false }));
    if (!validMilestones.length) throw new Error("AI couldn't generate milestones — please try again.");

    const result: GeneratedRoadmap = { description: parsed.description ?? "", milestones: validMilestones };
    return result;
  });
