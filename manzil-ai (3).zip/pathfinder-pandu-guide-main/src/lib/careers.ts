export type CareerCategory = {
  slug: string;
  name: string;
  emoji: string;
  overview: string;
  paths: string[];
  skills: string[];
  salaryRange: string;
  demand: string;
};

export const CAREER_CATEGORIES: CareerCategory[] = [
  { slug: "engineering", name: "Engineering", emoji: "⚙️", overview: "Build the physical and digital systems that power modern life — from bridges and robots to circuits and machines.", paths: ["Mechanical", "Electrical", "Civil", "Aerospace", "Robotics"], skills: ["Math", "Physics", "Problem solving", "CAD"], salaryRange: "₹5L – ₹40L+", demand: "Very High" },
  { slug: "medical", name: "Medical", emoji: "🩺", overview: "Heal, care, and save lives through medicine, surgery and clinical research.", paths: ["MBBS", "BDS", "BAMS", "Nursing", "Physiotherapy"], skills: ["Biology", "Empathy", "Focus", "Stamina"], salaryRange: "₹6L – ₹50L+", demand: "Very High" },
  { slug: "biology", name: "Biology & Research", emoji: "🧬", overview: "Explore living systems — genetics, ecology, biotech and the future of life sciences.", paths: ["Biotech", "Microbiology", "Genetics", "Marine Biology"], skills: ["Curiosity", "Lab skills", "Patience"], salaryRange: "₹4L – ₹25L", demand: "Growing" },
  { slug: "ai-tech", name: "AI & Technology", emoji: "🤖", overview: "Design intelligent systems and software that change how the world works.", paths: ["AI/ML Engineer", "Software Engineer", "Product Engineer", "AI Researcher"], skills: ["Coding", "Math", "Logical thinking"], salaryRange: "₹8L – ₹80L+", demand: "Explosive" },
  { slug: "data-science", name: "Data Science", emoji: "📊", overview: "Turn raw data into insights and decisions that move businesses and governments forward.", paths: ["Data Analyst", "Data Scientist", "BI Engineer"], skills: ["Statistics", "Python", "Storytelling"], salaryRange: "₹6L – ₹50L", demand: "Very High" },
  { slug: "cybersecurity", name: "Cybersecurity", emoji: "🛡️", overview: "Protect people and systems from digital attacks. One of the most in-demand careers globally.", paths: ["Pen Tester", "Security Analyst", "Cloud Security"], skills: ["Networks", "Linux", "Curiosity"], salaryRange: "₹6L – ₹60L", demand: "Very High" },
  { slug: "commerce", name: "Commerce & Finance", emoji: "💼", overview: "Run the engine of business — accounting, markets, banking and investing.", paths: ["CA", "CFA", "Investment Banking", "B.Com / BBA"], skills: ["Numeracy", "Analytical", "Communication"], salaryRange: "₹5L – ₹70L", demand: "High" },
  { slug: "design", name: "Design", emoji: "🎨", overview: "Shape products, brands, and experiences people love.", paths: ["UI/UX", "Graphic", "Product Design", "Animation"], skills: ["Visual sense", "Empathy", "Software tools"], salaryRange: "₹4L – ₹35L", demand: "Growing" },
  { slug: "law", name: "Law", emoji: "⚖️", overview: "Defend rights, draft policy, and resolve disputes through the practice of law.", paths: ["BA LLB", "Corporate Law", "Civil Services"], skills: ["Reading", "Debate", "Memory"], salaryRange: "₹5L – ₹50L+", demand: "Stable" },
  { slug: "government", name: "Government Jobs", emoji: "🏛️", overview: "Public service across UPSC, defence, banking and railways.", paths: ["UPSC", "SSC", "Banking PO", "Defence"], skills: ["GK", "Discipline", "Reasoning"], salaryRange: "₹4L – ₹25L", demand: "Stable" },
  { slug: "entrepreneurship", name: "Entrepreneurship", emoji: "🚀", overview: "Build your own thing — solve problems and create value at scale.", paths: ["Startup Founder", "Family Business", "D2C Brand"], skills: ["Risk taking", "Sales", "Leadership"], salaryRange: "Unlimited", demand: "Booming" },
  { slug: "content", name: "Content Creation", emoji: "🎬", overview: "Tell stories on YouTube, Instagram, podcasts and beyond.", paths: ["YouTuber", "Podcaster", "Writer", "Streamer"], skills: ["Creativity", "Editing", "Consistency"], salaryRange: "₹0 – ₹1Cr+", demand: "Growing" },
  { slug: "digital-marketing", name: "Digital Marketing", emoji: "📣", overview: "Grow brands online through SEO, ads, social and analytics.", paths: ["Performance", "SEO", "Social", "Brand"], skills: ["Writing", "Analytics", "Creativity"], salaryRange: "₹4L – ₹40L", demand: "Very High" },
  { slug: "physics", name: "Physics & Space", emoji: "🪐", overview: "Understand the universe — from particles to galaxies.", paths: ["Astrophysics", "Quantum", "ISRO/Research"], skills: ["Math", "Imagination", "Patience"], salaryRange: "₹5L – ₹30L", demand: "Niche" },
  { slug: "chemistry", name: "Chemistry", emoji: "⚗️", overview: "Drive medicine, materials, energy and food innovation.", paths: ["Pharma", "Materials", "Food Tech"], skills: ["Lab work", "Detail", "Math"], salaryRange: "₹4L – ₹25L", demand: "Steady" },
  { slug: "biology-medicine", name: "Allied Health", emoji: "💊", overview: "Support medicine through pharmacy, nutrition, therapy and more.", paths: ["Pharmacy", "Nutrition", "Optometry"], skills: ["Care", "Detail", "Science"], salaryRange: "₹3L – ₹20L", demand: "Growing" },
];
