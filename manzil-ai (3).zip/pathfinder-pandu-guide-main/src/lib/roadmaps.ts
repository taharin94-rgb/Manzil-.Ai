export type Milestone = { id: string; title: string; detail?: string; done: boolean };
export type RoadmapTemplate = {
  slug: string;
  career: string;
  emoji: string;
  exams: string[];
  milestones: Omit<Milestone, "done">[];
};

export const CAREER_ROADMAPS: RoadmapTemplate[] = [
  {
    slug: "doctor",
    career: "Doctor (MBBS)",
    emoji: "🩺",
    exams: ["NEET-UG", "AIIMS", "JIPMER"],
    milestones: [
      { id: "10", title: "Complete Class 10 with strong Science & Math" },
      { id: "stream", title: "Take Science (PCB) in Class 11" },
      { id: "neet-prep", title: "Begin NEET preparation (Bio, Phy, Chem)" },
      { id: "12", title: "Score 85%+ in Class 12 board exam" },
      { id: "neet", title: "Crack NEET-UG with a competitive rank" },
      { id: "mbbs", title: "Complete 5.5 year MBBS degree" },
      { id: "internship", title: "Finish 1 year compulsory internship" },
      { id: "pg", title: "Pursue PG (MD/MS) in chosen specialization" },
      { id: "practice", title: "Begin clinical practice or super-specialize" },
    ],
  },
  {
    slug: "software-engineer",
    career: "Software Engineer",
    emoji: "💻",
    exams: ["JEE Main", "JEE Advanced", "BITSAT", "State CET"],
    milestones: [
      { id: "10", title: "Complete Class 10 with strong Math" },
      { id: "stream", title: "Take Science (PCM) in Class 11" },
      { id: "coding", title: "Learn coding basics (Python or C++)" },
      { id: "jee-prep", title: "Begin JEE / entrance prep" },
      { id: "12", title: "Score 75%+ in Class 12 boards" },
      { id: "jee", title: "Crack JEE / state entrance exam" },
      { id: "btech", title: "Complete B.Tech / B.E. in CSE or IT" },
      { id: "projects", title: "Build 3+ real projects & contribute on GitHub" },
      { id: "intern", title: "Land a software internship" },
      { id: "placement", title: "Get placed at a tech company" },
    ],
  },
  {
    slug: "ca",
    career: "Chartered Accountant (CA)",
    emoji: "📊",
    exams: ["CA Foundation", "CA Intermediate", "CA Final"],
    milestones: [
      { id: "10", title: "Complete Class 10" },
      { id: "stream", title: "Take Commerce in Class 11" },
      { id: "foundation", title: "Register & clear CA Foundation" },
      { id: "12", title: "Complete Class 12" },
      { id: "inter", title: "Clear CA Intermediate (both groups)" },
      { id: "articleship", title: "Complete 3 year articleship training" },
      { id: "final", title: "Clear CA Final" },
      { id: "icai", title: "Become an ICAI member & start practice" },
    ],
  },
  {
    slug: "ias",
    career: "IAS / Civil Services",
    emoji: "🏛️",
    exams: ["UPSC CSE Prelims", "UPSC Mains", "UPSC Interview"],
    milestones: [
      { id: "10", title: "Complete Class 10" },
      { id: "stream", title: "Pick any stream (Arts often helps)" },
      { id: "12", title: "Complete Class 12" },
      { id: "grad", title: "Complete graduation in any discipline" },
      { id: "optional", title: "Pick UPSC optional subject" },
      { id: "prelims", title: "Clear UPSC Prelims" },
      { id: "mains", title: "Clear UPSC Mains" },
      { id: "interview", title: "Clear UPSC Personality Test" },
      { id: "lbsnaa", title: "Training at LBSNAA & posting" },
    ],
  },
  {
    slug: "designer",
    career: "Designer (UI/UX / Product)",
    emoji: "🎨",
    exams: ["NID DAT", "UCEED", "NIFT"],
    milestones: [
      { id: "10", title: "Complete Class 10" },
      { id: "stream", title: "Take any stream (Arts/Science both work)" },
      { id: "portfolio", title: "Build a sketch / design portfolio" },
      { id: "12", title: "Complete Class 12" },
      { id: "exam", title: "Crack NID / UCEED / NIFT entrance" },
      { id: "degree", title: "Complete design degree (B.Des)" },
      { id: "intern", title: "Intern at a studio or startup" },
      { id: "job", title: "Land a designer role" },
    ],
  },
  {
    slug: "lawyer",
    career: "Lawyer",
    emoji: "⚖️",
    exams: ["CLAT", "AILET", "LSAT India"],
    milestones: [
      { id: "10", title: "Complete Class 10" },
      { id: "stream", title: "Take any stream (Arts/Commerce common)" },
      { id: "12", title: "Score 75%+ in Class 12" },
      { id: "clat", title: "Crack CLAT / AILET" },
      { id: "llb", title: "Complete 5-year integrated BA-LLB" },
      { id: "bar", title: "Clear All India Bar Exam (AIBE)" },
      { id: "practice", title: "Intern under a senior, start practice" },
    ],
  },
  {
    slug: "entrepreneur",
    career: "Entrepreneur / Founder",
    emoji: "🚀",
    exams: ["Optional: CAT for MBA"],
    milestones: [
      { id: "10", title: "Complete Class 10" },
      { id: "skills", title: "Learn business basics + a hard skill" },
      { id: "12", title: "Complete Class 12 in any stream" },
      { id: "grad", title: "Graduate (BBA / B.Com / B.Tech)" },
      { id: "idea", title: "Validate a startup idea with real users" },
      { id: "mvp", title: "Build & launch an MVP" },
      { id: "team", title: "Find co-founder & first customers" },
      { id: "raise", title: "Raise seed round or bootstrap profitably" },
    ],
  },
  {
    slug: "ai-engineer",
    career: "AI / ML Engineer",
    emoji: "🤖",
    exams: ["JEE Main", "JEE Advanced"],
    milestones: [
      { id: "10", title: "Complete Class 10 with strong Math" },
      { id: "stream", title: "Take Science (PCM) in Class 11" },
      { id: "python", title: "Learn Python + Statistics" },
      { id: "jee", title: "Crack JEE / entrance for CS or AI branch" },
      { id: "btech", title: "Complete B.Tech in CSE/AI/Data Science" },
      { id: "ml", title: "Master ML, deep learning, build projects" },
      { id: "kaggle", title: "Compete on Kaggle, publish on GitHub" },
      { id: "job", title: "Land an AI / ML engineering role" },
    ],
  },
];

export function findRoadmap(slug: string) {
  return CAREER_ROADMAPS.find((r) => r.slug === slug);
}
