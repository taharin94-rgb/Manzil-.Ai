import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ careerName: z.string().min(1).max(120) });

export const generateParentMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");
    const { supabase, userId } = context;

    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name, class_level, board")
      .eq("id", userId)
      .maybeSingle();

    const { data: career } = await supabase
      .from("careers")
      .select("overview, skills, salary, growth")
      .eq("name", data.careerName)
      .maybeSingle();

    const system = [
      "You write a warm, respectful message from an Indian student to their parents, explaining why they want to pursue a specific career choice.",
      "The tone must be humble and loving — not defensive or arguing. It should acknowledge the parents' concerns (stability, respect in society, income) directly and address them honestly with real facts, not exaggeration.",
      "Structure: (1) a warm opening, (2) why this career genuinely interests the student, (3) honest practical facts — realistic salary range, job stability/demand, growth path — addressing common parent worries, (4) a respectful closing asking for their support and trust.",
      "Write in Hinglish (Hindi conversational tone, written in Roman/English letters) since that's how Indian students actually talk to parents — warm and natural, not a formal essay.",
      "Keep it under 200 words. Do not invent fake statistics — use general, honest, well-known facts about the field.",
      "Respond with ONLY the message text — no JSON, no markdown, no quotes around it.",
    ].join("\n");

    const userPrompt = [
      `Career the student wants to pursue: ${data.careerName}`,
      career?.overview ? `Career overview: ${career.overview}` : "",
      career?.salary ? `Realistic salary context: ${JSON.stringify(career.salary)}` : "",
      career?.growth ? `Growth/demand context: ${career.growth}` : "",
      profile ? `Student is in Class ${profile.class_level ?? "?"}, ${profile.board ?? ""} board.` : "",
    ].filter(Boolean).join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 700, thinkingConfig: { thinkingBudget: 0 } },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
    if (!text.trim()) throw new Error("AI couldn't generate a message — please try again.");

    return { message: text.trim() };
  });
