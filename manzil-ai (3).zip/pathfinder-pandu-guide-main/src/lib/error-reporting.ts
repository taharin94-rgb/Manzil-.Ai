type ErrorContext = Record<string, unknown>;

// Simple client-side error reporter. Logs to the console by default.
// Swap the body of this function for your own error-tracking service
// (Sentry, LogRocket, etc.) if you add one later.
export function reportAppError(error: unknown, context: ErrorContext = {}) {
  if (typeof window === "undefined") return;
  console.error("[app-error]", error, {
    route: window.location.pathname,
    ...context,
  });
}
