import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ careerSlug: z.string().min(1).max(80) });

export type CareerPrediction = {
  demandScore: number; // 1-10
  demandLabel: string; // e.g. "Growing fast"
  summary: string;
  timeline: { horizon: string; note: string }[]; // e.g. "2 years", "5 years", "10 years"
  risks: string[];
  drivers: string[];
};

export const predictCareerDemand = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const { data: cached } = await supabase
      .from("career_predictions")
      .select("prediction")
      .eq("career_slug", data.careerSlug)
      .maybeSingle();
    if (cached?.prediction) return cached.prediction as unknown as CareerPrediction;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");

    const { data: career, error: careerError } = await supabase
      .from("careers")
      .select("name, overview, growth, skills")
      .eq("slug", data.careerSlug)
      .maybeSingle();
    if (careerError) throw new Error(careerError.message);
    if (!career) throw new Error("Career not found");

    const system = [
      "You are an honest labour-market analyst forecasting future demand for a career in the Indian job market, for a Class 10/12 student deciding whether to pursue it.",
      "Base your forecast on realistic, well-known trends (automation/AI impact, industry growth, government policy, global trends) — do not invent specific statistics or cite fake reports. Where you're estimating/uncertain, say so in plain language rather than presenting a guess as a hard fact.",
      "Give a 'demandScore' 1-10 (10 = extremely high future demand) and a short 'demandLabel' (e.g. 'Growing fast', 'Stable', 'At risk from automation').",
      "Give a 2-3 sentence 'summary'.",
      "Give a 'timeline' array with exactly 3 entries for horizons '2 years', '5 years', '10 years', each with a 1-sentence 'note' on what's likely to change.",
      "Give 2-4 short 'risks' (things that could reduce demand, e.g. automation, oversupply of graduates) and 2-4 short 'drivers' (things pushing demand up).",
      "Be balanced and honest — don't oversell or undersell.",
      'Respond ONLY as JSON: { "demandScore": number, "demandLabel": string, "summary": string, "timeline": [{"horizon":string,"note":string}], "risks": [string], "drivers": [string] }. No markdown.',
    ].join("\n");

    const userPrompt = [
      `Career: ${career.name}`,
      career.overview ? `Overview: ${career.overview}` : "",
      career.growth ? `Known growth context: ${career.growth}` : "",
      `Key skills: ${(career.skills as string[] | null)?.join(", ") ?? ""}`,
    ].filter(Boolean).join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.6,
            maxOutputTokens: 1500,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let prediction: CareerPrediction;
    try {
      prediction = JSON.parse(text);
    } catch {
      throw new Error("AI returned an unexpected format — please try again.");
    }
    if (typeof prediction?.demandScore !== "number" || !Array.isArray(prediction?.timeline) || !prediction.timeline.length) {
      throw new Error("AI couldn't generate a prediction — please try again.");
    }

    const { error: insertError } = await supabase
      .from("career_predictions")
      .insert({ career_slug: data.careerSlug, prediction: prediction as never });
    if (insertError) console.error("[career_predictions cache] insert failed:", insertError.message);

    return prediction;
  });
