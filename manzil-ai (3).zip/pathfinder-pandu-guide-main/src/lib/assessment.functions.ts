import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ASSESSMENT_QUESTIONS } from "@/lib/questions";

const Input = z.object({ answers: z.array(z.string()).length(20) });

type Analysis = {
  stream: "Science" | "Commerce" | "Arts" | "Vocational";
  stream_reason: string;
  personality_summary: string;
  strengths: string[];
  weaknesses: string[];
  personality_traits: string[];
  learning_style: string;
  top_careers: { name: string; match: number; why: string; skills: string[]; future_scope: string; salary: string }[];
  encouragement: string;
};

export const analyzeAssessment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");

    const { supabase, userId } = context;
    const { data: profile } = await supabase.from("profiles").select("class_level, age, city, language, interests").eq("id", userId).maybeSingle();

    const qa = ASSESSMENT_QUESTIONS.map((q, i) => `Q${i + 1}: ${q}\nA${i + 1}: ${data.answers[i]}`).join("\n\n");

    const system = `You are Mr. Pandu Ram, a friendly, motivating AI career mentor for Indian students of Class 10 and 12. You analyze a student's 20-answer assessment and produce honest, personalized career guidance. Be warm, specific, and never generic. Match scores must reflect real fit (range 60-98). Use Indian career context (NEET, JEE, CA, UPSC, design colleges, etc).`;

    const userPrompt = `Student profile:
- Class: ${profile?.class_level ?? "unknown"}
- Age: ${profile?.age ?? "unknown"}
- City: ${profile?.city ?? "unknown"}
- Interests: ${(profile?.interests ?? []).join(", ") || "none stated"}

Assessment:
${qa}

Return STRICT JSON with this exact shape:
{
  "stream": "Science" | "Commerce" | "Arts" | "Vocational",
  "stream_reason": "2-3 sentences why this stream fits THIS student, referencing their actual answers",
  "personality_summary": "3-4 sentences describing who this student is, based on their answers — warm, specific, second person ('You are...')",
  "strengths": ["3-5 specific strengths"],
  "weaknesses": ["2-4 honest growth areas, phrased kindly and actionably"],
  "personality_traits": ["3-5 traits"],
  "learning_style": "one short phrase like 'visual hands-on learner'",
  "top_careers": [
    { "name": "Career", "match": 92, "why": "1-2 sentences referencing their answers", "skills": ["..."], "future_scope": "1 sentence", "salary": "₹X – ₹YL in India" }
  ],
  "encouragement": "A warm 2-sentence message from Pandu Ram, addressed to the student"
}
Return EXACTLY 5 careers, sorted by match descending. No prose outside JSON.`;

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: { responseMimeType: "application/json", maxOutputTokens: 2048, thinkingConfig: { thinkingBudget: 0 } },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";
    let analysis: Analysis;
    try { analysis = JSON.parse(text); } catch { throw new Error("Could not parse AI response"); }

    const responses: Record<string, string> = {};
    data.answers.forEach((a, i) => { responses[`q${i + 1}`] = a; });

    const { data: row, error } = await supabase
      .from("assessments")
      .insert({
        user_id: userId,
        responses: responses as never,
        analysis: analysis as never,
        status: "completed",
        completed_at: new Date().toISOString(),
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    return { id: row.id, analysis };
  });
