import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  careerASlug: z.string().min(1).max(80),
  careerBSlug: z.string().min(1).max(80),
});

export type BattleResult = {
  summary: string;
  rows: { label: string; a: string; b: string; winner: "a" | "b" | "tie" }[];
  verdict: string;
};

export const compareCareers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");
    const { supabase } = context;

    const [{ data: a, error: aErr }, { data: b, error: bErr }] = await Promise.all([
      supabase.from("careers").select("name, overview, skills, salary, growth").eq("slug", data.careerASlug).maybeSingle(),
      supabase.from("careers").select("name, overview, skills, salary, growth").eq("slug", data.careerBSlug).maybeSingle(),
    ]);
    if (aErr) throw new Error(aErr.message);
    if (bErr) throw new Error(bErr.message);
    if (!a || !b) throw new Error("Career not found");

    const system = [
      "You are an honest, no-hype Indian career counsellor comparing two careers side by side for a Class 10/12 student.",
      "Compare on exactly these 8 dimensions, in this order: Salary (India), Future demand, Required skills/difficulty to learn, Work-life balance, Education path length, Growth potential, Industries/job availability, Typical entry roadmap.",
      "In your 'summary' and 'verdict' text, never mention the number of dimensions/fields being compared — just write natural, direct comparison language.",
      "For each dimension give a short 'a' value (career A's answer), a short 'b' value (career B's answer), and a 'winner' field: \"a\" if career A is clearly better on that dimension, \"b\" if career B is, or \"tie\" if genuinely comparable. Be honest — don't force a winner if it's a toss-up.",
      "Also write a 1-2 sentence 'summary' of the overall comparison, and a 2-3 sentence honest 'verdict' — NOT declaring one career universally 'better', but guidance like 'pick A if you value X, pick B if you value Y'.",
      'Respond ONLY as JSON: { "summary": string, "rows": [{ "label": string, "a": string, "b": string, "winner": "a"|"b"|"tie" }], "verdict": string }. Exactly 8 rows. No markdown.',
    ].join("\n");

    const userPrompt = [
      `Career A: ${a.name}. Overview: ${a.overview ?? ""}. Skills: ${(a.skills as string[] | null)?.join(", ") ?? ""}. Salary: ${JSON.stringify(a.salary ?? {})}. Growth: ${a.growth ?? ""}`,
      `Career B: ${b.name}. Overview: ${b.overview ?? ""}. Skills: ${(b.skills as string[] | null)?.join(", ") ?? ""}. Salary: ${JSON.stringify(b.salary ?? {})}. Growth: ${b.growth ?? ""}`,
    ].join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.6,
            maxOutputTokens: 2048,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let parsed: BattleResult;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("AI returned an unexpected format — please try again.");
    }
    if (!Array.isArray(parsed?.rows) || !parsed.rows.length) throw new Error("AI couldn't generate a comparison — please try again.");

    return { ...parsed, careerAName: a.name, careerBName: b.name };
  });
