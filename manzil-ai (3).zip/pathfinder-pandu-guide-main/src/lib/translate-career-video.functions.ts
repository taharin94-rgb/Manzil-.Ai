import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { VideoSlide } from "@/lib/career-video.functions";

const LANG_NAMES: Record<string, string> = {
  mr: "Marathi", ta: "Tamil", te: "Telugu", bn: "Bengali",
  gu: "Gujarati", kn: "Kannada", ml: "Malayalam", pa: "Punjabi",
  hi: "Hindi", en: "English", hg: "Hinglish (Hindi written in Roman/English letters)",
};

const Input = z.object({
  careerSlug: z.string().min(1).max(80),
  lang: z.enum(["hi", "en", "hg", "mr", "ta", "te", "bn", "gu", "kn", "ml", "pa"]),
});

export const translateCareerVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    const { data: cached, error: fetchError } = await supabase
      .from("career_videos")
      .select("script")
      .eq("career_slug", data.careerSlug)
      .maybeSingle();
    if (fetchError) throw new Error(fetchError.message);
    if (!cached?.script) throw new Error("Video not generated yet");

    const script = cached.script as unknown as { slides: VideoSlide[] };
    if (script.slides[0]?.[data.lang]) return script; // already translated

    if (data.lang === "hi" || data.lang === "en" || data.lang === "hg") return script; // should already exist

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");

    const sourceSlides = script.slides.map((s, i) => ({
      i,
      hasStat: Boolean(s.stat),
      title: s.hi.title, label: s.hi.label, caption: s.hi.caption, text: s.hi.text,
    }));

    const system = [
      `Translate the following career-explainer video script from Hindi into ${LANG_NAMES[data.lang]}, in native script.`,
      "Keep the same meaning, tone, and length — this is a translation, not a rewrite. Keep it natural and spoken, not literal word-for-word if that sounds awkward.",
      "Return the SAME array structure, same order, same 'i' index for each slide, translating only the title/label/caption/text fields into the target language.",
      'Respond ONLY as JSON: { "slides": [{ "i": number, "title"?: string, "label"?: string, "caption": string, "text": string }] }. Include "title" only if the source had a title, "label" only if the source had a label. No markdown.',
    ].join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: JSON.stringify(sourceSlides) }] }],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.4,
            maxOutputTokens: 6000,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let translated: { slides: { i: number; title?: string; label?: string; caption: string; text: string }[] };
    try {
      translated = JSON.parse(text);
    } catch {
      throw new Error("Translation failed — please try again.");
    }
    if (!Array.isArray(translated?.slides) || !translated.slides.length) throw new Error("Translation failed — please try again.");

    const merged: VideoSlide[] = script.slides.map((slide, i) => {
      const t = translated.slides.find((x) => x.i === i);
      if (!t) return slide;
      return {
        ...slide,
        [data.lang]: { title: t.title, label: t.label, caption: t.caption, text: t.text },
      };
    });
    const mergedScript = { slides: merged };

    const { error: updateError } = await supabase
      .from("career_videos")
      .update({ script: mergedScript as never })
      .eq("career_slug", data.careerSlug);
    if (updateError) console.error("[career_videos translate cache] update failed:", updateError.message);

    return mergedScript;
  });
