import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ careerSlug: z.string().min(1).max(80) });

type LangContent = { title?: string; label?: string; caption: string; text: string };

export type VideoSlide = {
  icon: string;
  stat?: string;
  hi: LangContent;
  en: LangContent;
  hg: LangContent;
} & Partial<Record<"mr" | "ta" | "te" | "bn" | "gu" | "kn" | "ml" | "pa", LangContent>>;

type GeneratedScript = { slides: VideoSlide[] };

export const getCareerVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;

    // 1. Return cached script if we've already generated one for this career.
    const { data: cached } = await supabase
      .from("career_videos")
      .select("script")
      .eq("career_slug", data.careerSlug)
      .maybeSingle();
    if (cached?.script) return cached.script as unknown as GeneratedScript;

    // 2. No cache — generate one now with Gemini, grounded in this career's real data.
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");

    const { data: career, error: careerError } = await supabase
      .from("careers")
      .select("name, tagline, overview, skills, salary, growth, roadmap")
      .eq("slug", data.careerSlug)
      .maybeSingle();
    if (careerError) throw new Error(careerError.message);
    if (!career) throw new Error("Career not found");

    const system = [
      "You are an Indian career counsellor writing the script for a short (~5 minute) explainer video aimed at Class 10/12 students.",
      "The video is a series of 9-11 short slides. Each slide has ONE clear idea (an icon, an optional short stat, and narration text).",
      "Be 100% honest and accurate — real salary ranges, real difficulty, real time commitment, real day-to-day work. No hype, no exaggeration. Students should come away with a truthful, grounded picture, not a sales pitch.",
      "Cover, in order: (1) friendly intro naming the career, (2) what the job actually is day-to-day, (3) the real/unglamorous daily reality, (4) the education path from Class 10/12 onward (subjects, entrance exams, degree), (5) skills needed beyond a degree, (6) how long it realistically takes to become established, (7) honest salary ranges in India (entry/mid/senior), (8) real challenges/downsides of this field, (9) who this suits (interests/personality), (10) a warm, honest closing.",
      "Write EVERY slide's narration text in THREE versions: 'hi' (pure Hindi, Devanagari script), 'en' (English), and 'hg' (Hinglish — Hindi conversational content but written in Roman/English letters, like how Indian students actually text). All three must convey the same facts, just in different language/script — keep them natural for each, not literal translations.",
      "Each slide needs a short 'caption' (under 18 words, a condensed on-screen version) and a longer spoken 'text' (2-4 sentences, natural spoken language, this is what gets read aloud).",
      "For slides presenting a concrete number (education duration, salary range, timeline), also fill 'stat' (e.g. '₹3-8 lakh', '4-6 years', 'JEE / B.Tech') at the top level, and use 'label' instead of 'title' in each language object for that slide's short stat caption. For slides without a number, use 'title' instead of 'label'.",
      "Pick one emoji per slide (field: 'icon') that visually represents that slide's idea.",
      'Respond ONLY as JSON: { "slides": [ { "icon": "💻", "stat": "optional", "hi": {"title or label":"...", "caption":"...", "text":"..."}, "hg": {...}, "en": {...} } ] }. No markdown, no extra commentary.',
    ].join("\n");

    const userPrompt = [
      `Career: ${career.name}`,
      career.tagline ? `Tagline: ${career.tagline}` : "",
      career.overview ? `Overview: ${career.overview}` : "",
      `Skills: ${(career.skills as string[] | null)?.join(", ") ?? ""}`,
      `Salary data: ${JSON.stringify(career.salary ?? {})}`,
      career.growth ? `Growth/demand: ${career.growth}` : "",
      career.roadmap ? `Typical roadmap steps: ${(career.roadmap as { step: string }[] | null)?.map((r) => r.step).join(" -> ")}` : "",
    ].filter(Boolean).join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.7, maxOutputTokens: 8000, thinkingConfig: { thinkingBudget: 0 } },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let script: GeneratedScript;
    try {
      script = JSON.parse(text);
    } catch {
      throw new Error("AI returned an unexpected format — please try again.");
    }
    const validSlides = Array.isArray(script?.slides)
      ? script.slides.filter(
          (s) =>
            s && typeof s.icon === "string" &&
            s.hi?.text && s.hi?.caption &&
            s.hg?.text && s.hg?.caption &&
            s.en?.text && s.en?.caption,
        )
      : [];
    if (!validSlides.length) throw new Error("AI couldn't generate a valid video script — please try again.");
    script = { slides: validSlides };

    // 3. Cache it so future visitors (and re-visits) load instantly with no extra AI cost.
    const { error: insertError } = await supabase
      .from("career_videos")
      .insert({ career_slug: data.careerSlug, script: script as never });
    // If insert fails (e.g. a race where two students triggered generation at once
    // and one already cached it), that's fine — we still return the freshly generated script.
    if (insertError) console.error("[career_videos cache] insert failed:", insertError.message);

    return script;
  });
