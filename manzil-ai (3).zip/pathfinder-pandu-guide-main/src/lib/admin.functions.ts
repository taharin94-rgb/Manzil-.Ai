import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getAdminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: roleRow } = await supabaseAdmin
      .from("user_roles").select("role").eq("user_id", context.userId).eq("role", "admin").maybeSingle();
    if (!roleRow) throw new Error("Forbidden");

    const [users, assessments, subs, schools] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, full_name, class_level, city, created_at").order("created_at", { ascending: false }).limit(50),
      supabaseAdmin.from("assessments").select("id, status, created_at, user_id").order("created_at", { ascending: false }).limit(50),
      supabaseAdmin.from("subscriptions").select("user_id, plan, status, current_period_end"),
      supabaseAdmin.from("user_roles").select("user_id, role").eq("role", "school"),
    ]);
    const u = users.data ?? [];
    const a = assessments.data ?? [];
    const s = subs.data ?? [];
    return {
      users: u,
      assessments: a,
      subscriptions: s,
      schools: schools.data ?? [],
      counts: {
        users: u.length,
        completed: a.filter((x) => x.status === "completed").length,
        premium: s.filter((x) => x.plan !== "free" && x.status === "active").length,
      },
    };
  });
