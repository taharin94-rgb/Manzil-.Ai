import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ goalId: z.string().uuid(), careerName: z.string().min(1).max(120) });

export type DailyTask = { id: string; title: string; detail?: string };

export const generateDailyTasks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("AI is not configured");
    const { supabase, userId } = context;

    const [{ data: profile }, { data: career }] = await Promise.all([
      supabase.from("profiles").select("class_level, board, interests, language").eq("id", userId).maybeSingle(),
      supabase.from("careers").select("overview, skills, roadmap").eq("name", data.careerName).maybeSingle(),
    ]);

    const system = [
      "You create a rotating list of small, specific, ONE-SESSION daily action tasks for a student working toward a career — NOT big life milestones like 'finish Class 10' or 'clear an entrance exam'.",
      "Each task must be something the student can genuinely DO in a single sitting today: learn one specific concept/tool/language feature, watch one specific type of tutorial topic, practice a specific small skill, build one small thing, read about one specific concept.",
      "Order tasks so they build on each other logically (e.g. for a programmer: variables -> loops -> functions -> a small project -> ...).",
      "Produce exactly 14 tasks (2 weeks worth). Each needs a short 'title' (under 12 words, starts with a verb, e.g. 'Python mein loops seekho') and a 'detail' (1 sentence — what specifically to do/where, mentioning a real free resource type like YouTube/freeCodeCamp/official docs where natural, but don't invent fake resource names).",
      "Write every task in the student's chosen app language (given below) — natural and encouraging, like a friendly senior giving daily direction.",
      'Respond ONLY as JSON: { "tasks": [{ "title": string, "detail": string }] }. No markdown.',
    ].join("\n");

    const userPrompt = [
      `Career goal: ${data.careerName}`,
      career?.overview ? `Career overview: ${career.overview}` : "",
      `Key skills for this career: ${(career?.skills as string[] | null)?.join(", ") ?? ""}`,
      profile ? `Student: Class ${profile.class_level ?? "?"}, ${profile.board ?? "?"} board. Interests: ${(profile.interests ?? []).join(", ") || "none stated"}. App language: ${profile.language ?? "Hinglish"}.` : "",
    ].filter(Boolean).join("\n");

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.7,
            maxOutputTokens: 2500,
            thinkingConfig: { thinkingBudget: 0 },
          },
        }),
      },
    );

    if (resp.status === 429) throw new Error("Too many requests — please try again in a minute.");
    if (!resp.ok) throw new Error(`AI error: ${resp.status}`);
    const body = await resp.json();
    const text: string =
      body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";

    let parsed: { tasks: { title: string; detail?: string }[] };
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new Error("AI returned an unexpected format — please try again.");
    }
    const valid = Array.isArray(parsed?.tasks) ? parsed.tasks.filter((t) => t && typeof t.title === "string" && t.title.trim()) : [];
    if (!valid.length) throw new Error("AI couldn't generate tasks — please try again.");

    const tasks: DailyTask[] = valid.map((t, i) => ({ id: `${Date.now()}-${i}`, title: t.title, detail: t.detail }));

    const { error } = await supabase.from("goals").update({ daily_tasks: tasks as never }).eq("id", data.goalId);
    if (error) throw new Error(error.message);

    return { tasks };
  });
