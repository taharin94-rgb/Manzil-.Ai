export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      assessments: {
        Row: {
          analysis: Json | null
          completed_at: string | null
          created_at: string
          id: string
          responses: Json
          status: string
          user_id: string
        }
        Insert: {
          analysis?: Json | null
          completed_at?: string | null
          created_at?: string
          id?: string
          responses?: Json
          status?: string
          user_id: string
        }
        Update: {
          analysis?: Json | null
          completed_at?: string | null
          created_at?: string
          id?: string
          responses?: Json
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      careers: {
        Row: {
          category: string
          created_at: string
          emoji: string | null
          growth: string | null
          id: string
          name: string
          overview: string | null
          roadmap: Json
          salary: Json
          skills: Json
          slug: string
          tagline: string | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          emoji?: string | null
          growth?: string | null
          id?: string
          name: string
          overview?: string | null
          roadmap?: Json
          salary?: Json
          skills?: Json
          slug: string
          tagline?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          emoji?: string | null
          growth?: string | null
          id?: string
          name?: string
          overview?: string | null
          roadmap?: Json
          salary?: Json
          skills?: Json
          slug?: string
          tagline?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      career_predictions: {
        Row: {
          career_slug: string
          created_at: string
          prediction: Json
        }
        Insert: {
          career_slug: string
          created_at?: string
          prediction: Json
        }
        Update: {
          career_slug?: string
          created_at?: string
          prediction?: Json
        }
        Relationships: []
      }
      career_videos: {
        Row: {
          career_slug: string
          created_at: string
          script: Json
        }
        Insert: {
          career_slug: string
          created_at?: string
          script: Json
        }
        Update: {
          career_slug?: string
          created_at?: string
          script?: Json
        }
        Relationships: []
      }
      user_streaks: {
        Row: {
          user_id: string
          streak_count: number
          last_active_date: string
        }
        Insert: {
          user_id: string
          streak_count?: number
          last_active_date?: string
        }
        Update: {
          user_id?: string
          streak_count?: number
          last_active_date?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      goals: {
        Row: {
          created_at: string
          daily_tasks: Json
          description: string | null
          id: string
          milestones: Json
          progress: number
          target_date: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          daily_tasks?: Json
          description?: string | null
          id?: string
          milestones?: Json
          progress?: number
          target_date?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          daily_tasks?: Json
          description?: string | null
          id?: string
          milestones?: Json
          progress?: number
          target_date?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      invite_codes: {
        Row: {
          code: string
          created_at: string
          id: string
          intended_role: Database["public"]["Enums"]["app_role"]
          student_id: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          intended_role: Database["public"]["Enums"]["app_role"]
          student_id: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          intended_role?: Database["public"]["Enums"]["app_role"]
          student_id?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: []
      }
      parent_students: {
        Row: {
          created_at: string
          id: string
          parent_id: string
          student_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          parent_id: string
          student_id: string
        }
        Update: {
          created_at?: string
          id?: string
          parent_id?: string
          student_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          age: number | null
          board: string | null
          city: string | null
          class_level: string | null
          created_at: string
          full_name: string | null
          gender: string | null
          id: string
          interests: string[] | null
          language: string | null
          onboarded: boolean
          school_name: string | null
          updated_at: string
        }
        Insert: {
          age?: number | null
          board?: string | null
          city?: string | null
          class_level?: string | null
          created_at?: string
          full_name?: string | null
          gender?: string | null
          id: string
          interests?: string[] | null
          language?: string | null
          onboarded?: boolean
          school_name?: string | null
          updated_at?: string
        }
        Update: {
          age?: number | null
          board?: string | null
          city?: string | null
          class_level?: string | null
          created_at?: string
          full_name?: string | null
          gender?: string | null
          id?: string
          interests?: string[] | null
          language?: string | null
          onboarded?: boolean
          school_name?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      school_students: {
        Row: {
          created_at: string
          id: string
          school_id: string
          student_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          school_id: string
          student_id: string
        }
        Update: {
          created_at?: string
          id?: string
          school_id?: string
          student_id?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          current_period_end: string | null
          id: string
          plan: string
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          plan?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          plan?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_view_student: {
        Args: { _student: string; _viewer: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_premium: { Args: { _user: string }; Returns: boolean }
    }
    Enums: {
      app_role: "student" | "parent" | "school" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["student", "parent", "school", "admin"],
    },
  },
} as const
