import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Sparkle, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { predictCareerDemand, type CareerPrediction } from "@/lib/career-prediction.functions";

export const Route = createFileRoute("/_authenticated/prediction")({
  head: () => ({ meta: [{ title: "Career Prediction – Manzil AI" }] }),
  component: Prediction,
});

type CareerOption = { slug: string; name: string; emoji: string | null };

function Prediction() {
  const runPredict = useServerFn(predictCareerDemand);
  const { data: careers = [] } = useQuery<CareerOption[]>({
    queryKey: ["careers-picker"],
    queryFn: async () => (await supabase.from("careers").select("slug, name, emoji").order("name")).data as CareerOption[] ?? [],
  });

  const [search, setSearch] = useState("");
  const [slug, setSlug] = useState("");
  const [careerName, setCareerName] = useState("");
  const [prediction, setPrediction] = useState<CareerPrediction | null>(null);
  const [loading, setLoading] = useState(false);

  const filtered = careers.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));

  async function predict() {
    if (!slug) return toast.error("Pehle career pick karo");
    setLoading(true);
    setPrediction(null);
    try {
      const r = await runPredict({ data: { careerSlug: slug } });
      setPrediction(r);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Prediction generate nahi ho paayi");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-6 pb-24">
      <div className="flex items-center gap-2">
        <Sparkle className="h-6 w-6 text-accent" />
        <h1 className="font-display text-3xl font-semibold">Career Prediction 🔮</h1>
      </div>
      <p className="text-sm text-muted-foreground">Future mein kitni demand hogi is career ki — AI se pata karo.</p>

      {!slug ? (
        <div className="mt-5 rounded-3xl border border-border bg-card p-4 shadow-soft">
          <label className="flex items-center gap-2 rounded-full border border-input bg-card-soft px-3 py-2">
            <Search className="h-3.5 w-3.5 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`Search ${careers.length || "78+"} careers…`} className="w-full bg-transparent text-sm outline-none" />
          </label>
          <div className="mt-3 grid max-h-80 grid-cols-2 gap-2 overflow-y-auto pr-1">
            {filtered.map((c) => (
              <button
                key={c.slug}
                onClick={() => { setSlug(c.slug); setCareerName(c.name); }}
                className="rounded-2xl border border-border bg-card-soft p-3 text-left text-xs font-semibold"
              >
                <div className="text-lg">{c.emoji}</div>
                {c.name}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          <div className="flex items-center justify-between rounded-3xl bg-brand p-4 text-primary-foreground shadow-pop">
            <p className="font-display text-lg font-semibold">{careerName}</p>
            <button onClick={() => { setSlug(""); setPrediction(null); }} className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold">Badlo</button>
          </div>

          {!prediction && !loading && (
            <button onClick={predict} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-pop">🔮 Future dikhao</button>
          )}
          {loading && (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              <p className="text-xs text-muted-foreground">AI future demand analyze kar raha hai…</p>
            </div>
          )}
          {prediction && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 rounded-3xl border border-border bg-card p-4 shadow-soft">
                <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-brand text-xl font-bold text-primary-foreground">{prediction.demandScore}/10</div>
                <div>
                  <p className="font-display text-base font-semibold">{prediction.demandLabel}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{prediction.summary}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {prediction.timeline.map((t, i) => (
                  <div key={i} className="rounded-2xl border border-border bg-card p-3 text-center shadow-soft">
                    <p className="text-[11px] font-bold text-accent">{t.horizon}</p>
                    <p className="mt-1 text-[11px] leading-snug text-muted-foreground">{t.note}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-3xl border border-border bg-card p-3 shadow-soft">
                  <p className="text-[10px] font-bold uppercase text-success">Drivers ↑</p>
                  <ul className="mt-1 space-y-1 text-xs text-muted-foreground">
                    {prediction.drivers.map((d, i) => <li key={i}>• {d}</li>)}
                  </ul>
                </div>
                <div className="rounded-3xl border border-border bg-card p-3 shadow-soft">
                  <p className="text-[10px] font-bold uppercase text-destructive">Risks ↓</p>
                  <ul className="mt-1 space-y-1 text-xs text-muted-foreground">
                    {prediction.risks.map((r, i) => <li key={i}>• {r}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
