import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Users, Sparkles, Crown, School as SchoolIcon, LogOut } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getAdminOverview } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin – Manzil AI" }] }),
  component: AdminDash,
});

function AdminDash() {
  const fetchOverview = useServerFn(getAdminOverview);
  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: () => fetchOverview(),
    retry: false,
  });

  async function signOut() {
    await supabase.auth.signOut();
    toast.success("Signed out");
    window.location.href = "/";
  }

  if (error) {
    return <div className="mx-auto max-w-md px-5 pt-10 text-center"><p className="text-sm text-muted-foreground">Admin access required.</p></div>;
  }

  return (
    <div className="mx-auto max-w-2xl px-5 pt-8">
      <header className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Admin Panel</p>
          <h1 className="font-display text-3xl font-semibold">Overview</h1>
        </div>
        <button onClick={signOut} className="grid h-10 w-10 place-items-center rounded-2xl border border-border bg-card text-muted-foreground"><LogOut className="h-4 w-4" /></button>
      </header>

      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat icon={Users} label="Users" value={data?.counts.users ?? 0} />
        <Stat icon={Sparkles} label="Assessments" value={data?.counts.completed ?? 0} />
        <Stat icon={Crown} label="Premium" value={data?.counts.premium ?? 0} />
        <Stat icon={SchoolIcon} label="Schools" value={data?.schools.length ?? 0} />
      </div>

      <section className="mt-6">
        <h2 className="font-display text-lg font-semibold">Recent users</h2>
        <div className="mt-3 overflow-hidden rounded-3xl border border-border bg-card">
          {isLoading && <p className="p-4 text-sm text-muted-foreground">Loading…</p>}
          {data?.users.map((u) => (
            <div key={u.id} className="flex items-center justify-between border-b border-border px-4 py-2.5 text-sm last:border-0">
              <div className="min-w-0">
                <p className="truncate font-semibold">{u.full_name ?? "(no name)"}</p>
                <p className="text-xs text-muted-foreground">Class {u.class_level ?? "—"} • {u.city ?? ""}</p>
              </div>
              <p className="text-xs text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: number }) {
  return (
    <div className="rounded-3xl border border-border bg-card p-4">
      <div className="grid h-9 w-9 place-items-center rounded-2xl bg-primary/10 text-primary"><Icon className="h-5 w-5" /></div>
      <p className="mt-2 font-display text-2xl font-semibold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
