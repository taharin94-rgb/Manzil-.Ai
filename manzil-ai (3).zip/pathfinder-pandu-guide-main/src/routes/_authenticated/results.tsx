import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";
import { Sparkles, Brain, Briefcase, ArrowRight } from "lucide-react";

const Search = z.object({ id: z.string().optional() });

export const Route = createFileRoute("/_authenticated/results")({
  head: () => ({ meta: [{ title: "Your results – Manzil AI" }] }),
  validateSearch: (s) => Search.parse(s),
  component: Results,
});

type Analysis = {
  stream: string;
  stream_reason: string;
  personality_summary?: string;
  strengths: string[];
  weaknesses?: string[];
  personality_traits: string[];
  learning_style: string;
  top_careers: { name: string; match: number; why: string; skills: string[]; future_scope: string; salary: string }[];
  encouragement: string;
};

function Results() {
  const { id } = Route.useSearch();
  const { data, isLoading } = useQuery({
    queryKey: ["assessment", id ?? "latest"],
    queryFn: async () => {
      const q = supabase.from("assessments").select("*").order("created_at", { ascending: false });
      const { data } = id ? await q.eq("id", id).maybeSingle() : await q.limit(1).maybeSingle();
      return data;
    },
  });

  if (isLoading) return <div className="grid min-h-[60vh] place-items-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (!data?.analysis) {
    return (
      <div className="mx-auto max-w-md px-5 pt-10 text-center">
        <PanduRam className="mx-auto h-28 w-28" />
        <p className="mt-4 text-muted-foreground">No assessment yet.</p>
        <Link to="/assessment" className="mt-4 inline-block rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-primary-foreground">Take the test</Link>
      </div>
    );
  }
  const a = data.analysis as unknown as Analysis;

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <div className="rounded-3xl bg-brand p-5 text-primary-foreground shadow-pop">
        <div className="flex items-center gap-3">
          <PanduRam className="h-16 w-16 shrink-0" />
          <div>
            <p className="text-xs uppercase tracking-wide opacity-80">Recommended stream</p>
            <p className="font-display text-3xl font-semibold">{a.stream}</p>
          </div>
        </div>
        <p className="mt-3 text-sm leading-relaxed opacity-95">{a.stream_reason}</p>
      </div>

      {a.personality_summary && (
        <Section icon={Sparkles} title="Who you are">
          <p className="text-[15px] leading-relaxed text-foreground">{a.personality_summary}</p>
        </Section>
      )}

      <Section icon={Brain} title="Your strengths">
        <div className="flex flex-wrap gap-2">
          {a.strengths.map((s) => (
            <span key={s} className="rounded-full bg-accent/15 px-3 py-1 text-xs font-medium text-accent">{s}</span>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted-foreground"><span className="font-semibold text-foreground">Learning style:</span> {a.learning_style}</p>
      </Section>

      {a.weaknesses && a.weaknesses.length > 0 && (
        <Section icon={Brain} title="Areas to grow">
          <ul className="space-y-1.5 text-sm">
            {a.weaknesses.map((w) => (
              <li key={w} className="flex gap-2"><span className="text-accent">•</span><span>{w}</span></li>
            ))}
          </ul>
        </Section>
      )}

      <Section icon={Briefcase} title="Top career matches">
        <div className="space-y-3">
          {a.top_careers.map((c, i) => (
            <div key={c.name} className="rounded-2xl border border-border bg-card-soft p-4">
              <div className="flex items-center justify-between">
                <p className="font-display text-lg font-semibold">{i + 1}. {c.name}</p>
                <span className="rounded-full bg-primary/15 px-3 py-1 text-sm font-bold text-primary">{c.match}%</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-brand" style={{ width: `${c.match}%` }} />
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{c.why}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {c.skills.map((s) => <span key={s} className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-medium">{s}</span>)}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div><p className="text-muted-foreground">Salary</p><p className="font-semibold">{c.salary}</p></div>
                <div><p className="text-muted-foreground">Scope</p><p className="font-semibold">{c.future_scope}</p></div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section icon={Sparkles} title="Message from Mr. Pandu Ram">
        <p className="text-[15px] italic leading-relaxed text-foreground">"{a.encouragement}"</p>
      </Section>

      <Link to="/chat" className="mt-8 flex items-center justify-center gap-2 rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft">
        Ask Pandu Ram anything <ArrowRight className="h-4 w-4" />
      </Link>
      <Link to="/assessment" className="mb-8 mt-3 flex items-center justify-center gap-2 rounded-2xl border border-border bg-card py-3 text-sm font-semibold text-foreground shadow-soft">
        🔄 Retake the assessment
      </Link>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <section className="mt-6">
      <div className="mb-3 flex items-center gap-2">
        <div className="grid h-8 w-8 place-items-center rounded-xl bg-accent/15 text-accent"><Icon className="h-4 w-4" /></div>
        <h2 className="font-display text-lg font-semibold">{title}</h2>
      </div>
      <div className="rounded-3xl border border-border bg-card p-4 shadow-soft">{children}</div>
    </section>
  );
}
