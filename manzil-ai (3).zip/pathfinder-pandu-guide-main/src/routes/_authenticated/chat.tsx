import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Send, Mic, Square, Volume2, VolumeX, Pause, Play, StopCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sendChat } from "@/lib/chat.functions";
import { PanduRam } from "@/components/PanduRam";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({ meta: [{ title: "Mr. Pandu Ram – Manzil AI" }] }),
  component: Chat,
});

type Msg = { id: string; role: string; content: string };
type VoiceState = "stopped" | "speaking" | "paused";

const SPEEDS = [0.75, 1, 1.25, 1.5] as const;

function Chat() {
  const qc = useQueryClient();
  const send = useServerFn(sendChat);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [muted, setMuted] = useState(true);
  const [rate, setRate] = useState<number>(1);
  const [voiceState, setVoiceState] = useState<VoiceState>("stopped");
  const endRef = useRef<HTMLDivElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const speechChunksRef = useRef<string[]>([]);
  const chunkIndexRef = useRef(0);
  const rateRef = useRef(1);

  const { data: messages = [] } = useQuery<Msg[]>({
    queryKey: ["chat"],
    queryFn: async () =>
      (await supabase.from("chat_messages").select("id, role, content").order("created_at", { ascending: true })).data ?? [],
  });

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);

  // Stop any speech on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  function stopSpeaking() {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    utteranceRef.current = null;
    speechChunksRef.current = [];
    chunkIndexRef.current = 0;
    setVoiceState("stopped");
  }

  // Native speechSynthesis.pause()/resume() is unreliable across browsers
  // (especially Chrome, where resume() often silently does nothing after a
  // few seconds). To make pause/resume and live speed changes actually work,
  // we split replies into sentence-sized chunks and speak them one at a
  // time — "pause" just stops mid-list and remembers the chunk index,
  // "resume" re-speaks from that index, and changing speed restarts the
  // current chunk at the new rate.
  function splitIntoChunks(text: string): string[] {
    const parts = text.match(/[^.!?।]+[.!?।]*/g) ?? [text];
    return parts.map((p) => p.trim()).filter(Boolean);
  }

  function speakChunkAt(i: number) {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const chunks = speechChunksRef.current;
    if (i >= chunks.length) {
      utteranceRef.current = null;
      setVoiceState("stopped");
      return;
    }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(chunks[i]);
    u.rate = rateRef.current;
    u.pitch = 1;
    const voices = window.speechSynthesis.getVoices();
    const indian = voices.find((v) => /en-IN|hi-IN/i.test(v.lang));
    if (indian) u.voice = indian;
    u.onstart = () => setVoiceState("speaking");
    u.onend = () => {
      chunkIndexRef.current = i + 1;
      speakChunkAt(i + 1);
    };
    u.onerror = () => { utteranceRef.current = null; setVoiceState("stopped"); };
    utteranceRef.current = u;
    window.speechSynthesis.speak(u);
  }

  function pauseSpeaking() {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    setVoiceState("paused");
  }

  function resumeSpeaking() {
    speakChunkAt(chunkIndexRef.current);
  }

  function changeRate(next: number) {
    setRate(next);
    rateRef.current = next;
    // Apply immediately: restart the current chunk at the new speed
    // instead of only affecting the next reply.
    if (voiceState === "speaking") speakChunkAt(chunkIndexRef.current);
  }

  function speak(content: string) {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    speechChunksRef.current = splitIntoChunks(content);
    chunkIndexRef.current = 0;
    speakChunkAt(0);
  }

  async function submitMessage(message: string) {
    if (!message.trim() || busy) return;
    // Auto-cancel any ongoing speech when a new question is asked
    stopSpeaking();
    setText("");
    setBusy(true);
    qc.setQueryData<Msg[]>(["chat"], (prev = []) => [
      ...prev,
      { id: `tmp-${Date.now()}`, role: "user", content: message },
    ]);
    try {
      const result = await send({ data: { message } });
      await qc.invalidateQueries({ queryKey: ["chat"] });
      if (!muted && result?.reply) speak(result.reply);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Send failed");
    } finally {
      setBusy(false);
    }
  }

  async function startRecording() {
    if (recording || busy) return;
    stopSpeaking();
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch {
      return toast.error("Microphone access denied");
    }
    const mimeType = ["audio/webm", "audio/mp4"].find((t) => MediaRecorder.isTypeSupported(t));
    if (!mimeType) {
      stream.getTracks().forEach((t) => t.stop());
      return toast.error("This browser can't record audio");
    }
    let rec: MediaRecorder;
    try {
      rec = new MediaRecorder(stream, { mimeType });
    } catch {
      stream.getTracks().forEach((t) => t.stop());
      return toast.error("Could not start recorder");
    }
    chunksRef.current = [];
    rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
    rec.onerror = () => {
      stream.getTracks().forEach((t) => t.stop());
      recorderRef.current = null;
      setRecording(false);
      toast.error("Recording error");
    };
    rec.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      recorderRef.current = null;
      setRecording(false);
      const blob = new Blob(chunksRef.current, { type: rec.mimeType });
      chunksRef.current = [];
      if (blob.size < 1024) return toast.error("Recording too short, try again");
      const fd = new FormData();
      fd.append("file", blob, `voice.${rec.mimeType.includes("mp4") ? "mp4" : "webm"}`);
      setBusy(true);
      try {
        const resp = await fetch("/api/transcribe", { method: "POST", body: fd });
        if (!resp.ok) throw new Error(await resp.text());
        const { text: transcribed } = await resp.json();
        if (transcribed?.trim()) await submitMessage(transcribed.trim());
        else toast.error("Couldn't hear anything");
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Transcription failed");
      } finally {
        setBusy(false);
      }
    };
    recorderRef.current = rec;
    try {
      rec.start();
      setRecording(true);
    } catch {
      stream.getTracks().forEach((t) => t.stop());
      recorderRef.current = null;
      toast.error("Could not start recording");
    }
  }

  function stopRecording() {
    const rec = recorderRef.current;
    if (rec && rec.state !== "inactive") {
      try { rec.stop(); } catch { /* ignore */ }
    } else {
      setRecording(false);
    }
  }

  // Ensure mic + speech are released on unmount
  useEffect(() => {
    return () => {
      const rec = recorderRef.current;
      if (rec && rec.state !== "inactive") {
        try { rec.stop(); } catch { /* ignore */ }
      }
    };
  }, []);


  const stateLabel =
    voiceState === "speaking" ? "🔊 Speaking…" :
    voiceState === "paused" ? "⏸ Paused" :
    muted ? "🔇 Muted" : "● Online • Your AI mentor";

  return (
    <div className="mx-auto flex h-[calc(100dvh-6rem)] max-w-md flex-col overflow-hidden px-4 pt-4">
      <header className="shrink-0 flex items-center gap-3 rounded-3xl border border-border bg-card px-3 py-2 shadow-soft">
        <PanduRam className="h-12 w-12" />
        <div className="flex-1 min-w-0">
          <p className="font-display text-base font-semibold leading-tight">Mr. Pandu Ram</p>
          <p className="truncate text-xs text-success">{stateLabel}</p>
        </div>
        <button
          onClick={() => { const next = !muted; setMuted(next); if (next) stopSpeaking(); }}
          className={"grid h-9 w-9 place-items-center rounded-2xl " + (!muted ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground")}
          aria-label={muted ? "Unmute voice" : "Mute voice"}
        >
          {!muted ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>
      </header>

      {!muted && (
        <div className="mt-2 shrink-0 flex flex-wrap items-center gap-2 rounded-3xl border border-border bg-card-soft px-3 py-2 text-xs">
          <button
            onClick={voiceState === "paused" ? resumeSpeaking : pauseSpeaking}
            disabled={voiceState === "stopped"}
            className="flex items-center gap-1 rounded-full bg-secondary px-3 py-1 font-semibold disabled:opacity-40"
          >
            {voiceState === "paused" ? <><Play className="h-3 w-3" /> Resume</> : <><Pause className="h-3 w-3" /> Pause</>}
          </button>
          <button
            onClick={stopSpeaking}
            disabled={voiceState === "stopped"}
            className="flex items-center gap-1 rounded-full bg-secondary px-3 py-1 font-semibold disabled:opacity-40"
          >
            <StopCircle className="h-3 w-3" /> Stop
          </button>
          <div className="ml-auto flex items-center gap-1">
            <span className="text-muted-foreground">Speed</span>
            {SPEEDS.map((s) => (
              <button
                key={s}
                onClick={() => changeRate(s)}
                className={"rounded-full px-2 py-0.5 font-semibold " + (rate === s ? "bg-brand text-primary-foreground" : "bg-secondary text-muted-foreground")}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 min-h-0 flex-1 space-y-3 overflow-y-auto">
        {messages.length === 0 && (
          <div className="rounded-3xl border border-border bg-card-soft p-4 text-sm">
            <p className="font-semibold">Namaste! 👋 I'm Pandu Ram.</p>
            <p className="mt-1 text-muted-foreground">Ask me anything — type, or tap the mic to talk.</p>
            <div className="mt-3 space-y-1.5">
              {["Should I take Science or Commerce?", "How do I prepare for NEET in Class 11?", "What career fits a creative person?"].map((s) => (
                <button key={s} onClick={() => setText(s)} className="block w-full rounded-2xl bg-secondary px-3 py-2 text-left text-xs font-medium hover:bg-accent/10">{s}</button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m) => (
          <div key={m.id} className={"flex " + (m.role === "user" ? "justify-end" : "justify-start")}>
            <div className={"max-w-[85%] whitespace-pre-wrap rounded-3xl px-4 py-2.5 text-sm " + (m.role === "user" ? "bg-brand text-primary-foreground" : "border border-border bg-card text-foreground")}>
              {m.content}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex justify-start">
            <div className="rounded-3xl border border-border bg-card px-4 py-3">
              <div className="flex gap-1">
                <span className="h-2 w-2 animate-bounce rounded-full bg-accent [animation-delay:-0.3s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-accent [animation-delay:-0.15s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-accent" />
              </div>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form onSubmit={(e) => { e.preventDefault(); submitMessage(text); }} className="mt-3 flex shrink-0 items-center gap-2 pb-2">
        <button type="button" onClick={recording ? stopRecording : startRecording} className={"grid h-12 w-12 shrink-0 place-items-center rounded-full text-primary-foreground shadow-soft " + (recording ? "bg-destructive animate-pulse" : "bg-accent")} aria-label="Mic">
          {recording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
        </button>
        <input
          value={text} onChange={(e) => setText(e.target.value)}
          placeholder={recording ? "Listening…" : "Ask Pandu Ram…"}
          className="flex-1 rounded-full border border-input bg-card px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2"
        />
        <button type="submit" disabled={!text.trim() || busy} className="grid h-12 w-12 place-items-center rounded-full bg-brand text-primary-foreground shadow-soft disabled:opacity-50" aria-label="Send">
          <Send className="h-5 w-5" />
        </button>
      </form>
    </div>
  );
}
