import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Search } from "lucide-react";
import { CareerDetailModal } from "@/components/CareerDetailModal";

export const Route = createFileRoute("/_authenticated/explore")({
  head: () => ({ meta: [{ title: "Explore careers – Manzil AI" }] }),
  component: Explore,
});

type Career = { slug: string; name: string; tagline: string | null; emoji: string | null; salary: { entry?: string } };

function Explore() {
  const [q, setQ] = useState("");
  const [openSlug, setOpenSlug] = useState<string | null>(null);
  const { data: careers = [] } = useQuery<Career[]>({
    queryKey: ["careers"],
    queryFn: async () => (await supabase.from("careers").select("slug, name, tagline, emoji, salary").order("name")).data as Career[] ?? [],
  });
  const list = careers.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <h1 className="font-display text-3xl font-semibold">Explore careers</h1>
      <p className="text-sm text-muted-foreground">{careers.length}+ career paths — common and lesser-known. Tap any card.</p>

      <label className="mt-4 flex items-center gap-2 rounded-full border border-input bg-card px-4 py-2.5">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search careers" className="w-full bg-transparent text-sm outline-none" />
      </label>

      <div className="mt-4 grid grid-cols-2 gap-3">
        {list.map((c) => (
          <button
            key={c.slug}
            onClick={() => setOpenSlug(c.slug)}
            className="rounded-3xl border border-border bg-card p-4 text-left shadow-soft transition active:scale-[0.98]"
          >
            <div className="text-3xl">{c.emoji}</div>
            <p className="mt-2 font-display text-base font-semibold leading-tight">{c.name}</p>
            <p className="mt-1 line-clamp-2 text-[11px] text-muted-foreground">{c.tagline}</p>
            <p className="mt-1 text-xs font-semibold text-primary">{c.salary?.entry ?? ""}</p>
          </button>
        ))}
      </div>

      {openSlug && <CareerDetailModal slug={openSlug} onClose={() => setOpenSlug(null)} />}
    </div>
  );
}
