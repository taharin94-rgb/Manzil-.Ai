import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { redeemInviteCode } from "@/lib/invites.functions";
import { PanduRam } from "@/components/PanduRam";

export const Route = createFileRoute("/_authenticated/redeem")({
  head: () => ({ meta: [{ title: "Link to student – Manzil AI" }] }),
  component: Redeem,
});

function Redeem() {
  const navigate = useNavigate();
  const redeem = useServerFn(redeemInviteCode);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const { role } = await redeem({ data: { code: code.toUpperCase() } });
      toast.success("Linked successfully!");
      navigate({ to: role === "parent" ? "/parent" : "/school" });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not link");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-10 text-center">
      <PanduRam className="mx-auto h-24 w-24" />
      <h1 className="mt-3 font-display text-2xl font-semibold">Enter your student's code</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Ask your student to share their 8-character invite code from their dashboard.
      </p>
      <form onSubmit={submit} className="mt-6 space-y-3">
        <input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="ABCD1234"
          maxLength={8}
          className="w-full rounded-2xl border border-input bg-card px-4 py-4 text-center font-mono text-2xl tracking-widest outline-none ring-ring/30 focus:ring-2"
        />
        <button disabled={busy || code.length < 4} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-50">
          {busy ? "Linking…" : "Link to student"}
        </button>
      </form>
    </div>
  );
}
