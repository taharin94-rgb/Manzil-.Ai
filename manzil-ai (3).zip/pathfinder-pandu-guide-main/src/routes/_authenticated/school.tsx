import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Plus, LogOut, School as SchoolIcon, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/school")({
  head: () => ({ meta: [{ title: "School dashboard – Manzil AI" }] }),
  component: SchoolDashboard,
});

type Row = {
  id: string;
  full_name: string | null;
  class_level: string | null;
  done: boolean;
  stream: string | null;
};

function SchoolDashboard() {
  const { data: rows = [], isLoading } = useQuery<Row[]>({
    queryKey: ["school-students"],
    queryFn: async () => {
      const { data: links } = await supabase.from("school_students").select("student_id");
      if (!links?.length) return [];
      const ids = links.map((l) => l.student_id);
      const [{ data: profiles }, { data: assessments }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, class_level").in("id", ids),
        supabase.from("assessments").select("user_id, status, analysis").in("user_id", ids).eq("status", "completed"),
      ]);
      return ids.map((id) => {
        const p = profiles?.find((x) => x.id === id);
        const a = assessments?.find((x) => x.user_id === id);
        const an = a?.analysis as { stream?: string } | undefined;
        return {
          id,
          full_name: p?.full_name ?? null,
          class_level: p?.class_level ?? null,
          done: !!a,
          stream: an?.stream ?? null,
        };
      });
    },
  });

  async function signOut() {
    await supabase.auth.signOut();
    toast.success("Signed out");
    window.location.href = "/";
  }

  const completed = rows.filter((r) => r.done).length;
  const pending = rows.length - completed;

  return (
    <div className="mx-auto max-w-md px-5 pt-8">
      <header className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">School Portal</p>
          <h1 className="font-display text-3xl font-semibold">Students</h1>
        </div>
        <button onClick={signOut} className="grid h-10 w-10 place-items-center rounded-2xl border border-border bg-card text-muted-foreground"><LogOut className="h-4 w-4" /></button>
      </header>

      <div className="mt-5 grid grid-cols-3 gap-3 text-center">
        <Stat icon={SchoolIcon} label="Linked" value={rows.length} tint="brand" />
        <Stat icon={CheckCircle2} label="Done" value={completed} tint="success" />
        <Stat icon={Clock} label="Pending" value={pending} tint="muted" />
      </div>

      <Link to="/redeem" className="mt-4 flex items-center gap-2 rounded-2xl bg-accent/10 px-4 py-3 text-sm font-semibold text-accent">
        <Plus className="h-4 w-4" /> Link a student with their code
      </Link>

      <div className="mt-5 space-y-2">
        {isLoading && <p className="text-center text-sm text-muted-foreground">Loading…</p>}
        {!isLoading && rows.length === 0 && (
          <p className="rounded-3xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No students linked yet.</p>
        )}
        {rows.map((r) => (
          <div key={r.id} className="flex items-center justify-between rounded-2xl border border-border bg-card p-3">
            <div className="min-w-0">
              <p className="font-display text-sm font-semibold">{r.full_name ?? "Student"}</p>
              <p className="text-xs text-muted-foreground">Class {r.class_level ?? "—"}</p>
            </div>
            {r.done ? (
              <span className="rounded-full bg-success/15 px-3 py-1 text-xs font-bold text-success">{r.stream}</span>
            ) : (
              <span className="rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">Pending</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, tint }: { icon: React.ComponentType<{ className?: string }>; label: string; value: number; tint: "brand" | "success" | "muted" }) {
  const cls = tint === "brand" ? "bg-primary/10 text-primary" : tint === "success" ? "bg-success/15 text-success" : "bg-muted text-muted-foreground";
  return (
    <div className="rounded-3xl border border-border bg-card p-3">
      <div className={"mx-auto grid h-8 w-8 place-items-center rounded-2xl " + cls}><Icon className="h-4 w-4" /></div>
      <p className="mt-1 font-display text-xl font-semibold">{value}</p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
    </div>
  );
}
