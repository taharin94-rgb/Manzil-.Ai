import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Crown, ArrowLeft } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/pricing")({
  head: () => ({ meta: [{ title: "Premium – Manzil AI" }] }),
  component: Pricing,
});

const FREE = [
  "20-question career assessment",
  "Stream recommendation",
  "Top 5 career matches",
  "3 chats / day with Mr. Pandu Ram",
  "Basic roadmap",
];
const PREMIUM = [
  "Everything in Free",
  "Unlimited chats with Mr. Pandu Ram",
  "Voice chat (talk + listen)",
  "Detailed personalised roadmap",
  "Goal tracking & reminders",
  "Parent & school portal access",
  "Re-take assessment anytime",
];

function Pricing() {
  const { data: sub } = useQuery({
    queryKey: ["sub"],
    queryFn: async () => (await supabase.from("subscriptions").select("plan, status, current_period_end").maybeSingle()).data,
  });
  const isPremium = sub && sub.plan !== "free" && sub.status === "active";

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <h1 className="mt-3 font-display text-3xl font-semibold">Unlock your full path</h1>
      <p className="text-sm text-muted-foreground">Go further with Mr. Pandu Ram.</p>

      <div className="mt-5 rounded-3xl border border-border bg-card p-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Free</p>
        <p className="mt-1 font-display text-3xl font-semibold">₹0</p>
        <ul className="mt-3 space-y-2">
          {FREE.map((f) => <li key={f} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4 text-success" /> {f}</li>)}
        </ul>
      </div>

      <div className="mt-4 rounded-3xl bg-brand p-5 text-primary-foreground shadow-pop">
        <div className="flex items-center gap-2"><Crown className="h-5 w-5" /><p className="text-xs font-semibold uppercase tracking-wider opacity-90">Premium — Monthly</p></div>
        <div className="mt-1 flex items-baseline gap-2">
          <p className="font-display text-3xl font-semibold">₹99</p>
          <p className="opacity-90">/ month</p>
        </div>
        <ul className="mt-3 space-y-2">
          {PREMIUM.map((f) => <li key={f} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4" /> {f}</li>)}
        </ul>
        <button
          disabled={!!isPremium}
          onClick={() => alert("Payment checkout will activate once the workspace owner enables Stripe payments.")}
          className="mt-5 w-full rounded-2xl bg-primary-foreground py-3 text-sm font-semibold text-primary shadow-soft disabled:opacity-60"
        >
          {isPremium ? "You're Premium 🎉" : "Upgrade — ₹99 / month"}
        </button>
        <p className="mt-2 text-center text-[11px] opacity-80">Secure checkout. Cancel anytime.</p>
      </div>

      <div className="mt-4 rounded-3xl border-2 border-primary bg-card p-5 shadow-pop">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><Crown className="h-5 w-5 text-primary" /><p className="text-xs font-semibold uppercase tracking-wider text-primary">Premium — Yearly</p></div>
          <span className="rounded-full bg-success/15 px-2 py-1 text-[10px] font-bold text-success">Save ₹189</span>
        </div>
        <div className="mt-1 flex items-baseline gap-2">
          <p className="font-display text-3xl font-semibold">₹999</p>
          <p className="text-muted-foreground">/ year</p>
        </div>
        <p className="text-xs text-muted-foreground">Just ₹83/month, billed once a year</p>
        <ul className="mt-3 space-y-2">
          {PREMIUM.map((f) => <li key={f} className="flex items-start gap-2 text-sm"><Check className="mt-0.5 h-4 w-4 text-success" /> {f}</li>)}
        </ul>
        <button
          disabled={!!isPremium}
          onClick={() => alert("Payment checkout will activate once the workspace owner enables Stripe payments.")}
          className="mt-5 w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60"
        >
          {isPremium ? "You're Premium 🎉" : "Upgrade — ₹999 / year"}
        </button>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">Secure checkout. Cancel anytime.</p>
      </div>
    </div>
  );
}
