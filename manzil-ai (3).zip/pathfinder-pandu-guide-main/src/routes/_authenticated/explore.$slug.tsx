import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, MessageCircle, TrendingUp, IndianRupee, Sparkles, Map, Video } from "lucide-react";
import { getCareerVideo } from "@/lib/career-video.functions";
import { CareerVideoPlayer } from "@/components/CareerVideoPlayer";
import { VideoErrorBoundary } from "@/components/VideoErrorBoundary";

export const Route = createFileRoute("/_authenticated/explore/$slug")({
  head: ({ params }) => ({ meta: [{ title: `${params.slug} – Manzil AI` }] }),
  component: CareerDetail,
});

type Career = {
  slug: string;
  name: string;
  tagline: string | null;
  overview: string | null;
  skills: string[];
  salary: { entry?: string; mid?: string; senior?: string };
  growth: string | null;
  roadmap: { step: string }[];
  emoji: string | null;
};

function CareerDetail() {
  const { slug } = Route.useParams();
  const { data: c, isLoading, error: careerError } = useQuery<Career | null>({
    queryKey: ["career", slug],
    queryFn: async () => {
      const { data, error } = await supabase.from("careers").select("*").eq("slug", slug).maybeSingle();
      if (error) throw error;
      return data as Career | null;
    },
    retry: false,
  });

  const runGetCareerVideo = useServerFn(getCareerVideo);
  const { data: videoScript, isLoading: videoLoading, error: videoError, refetch: retryVideo, isFetched: videoFetched } = useQuery({
    queryKey: ["career-video", slug],
    queryFn: () => runGetCareerVideo({ data: { careerSlug: slug } }),
    enabled: false,
    retry: false,
  });

  if (isLoading) return <div className="grid min-h-[40vh] place-items-center"><div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (careerError) return <div className="p-8 text-center text-sm text-destructive">Career load nahi hui: {careerError.message}</div>;
  if (!c) return <div className="p-8 text-center text-sm">Career not found.</div>;

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <Link to="/explore" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Explore</Link>
      <div className="mt-3 rounded-3xl bg-brand p-5 text-primary-foreground shadow-pop">
        <div className="text-5xl">{c.emoji}</div>
        <h1 className="mt-2 font-display text-3xl font-semibold">{c.name}</h1>
        <p className="mt-1 text-sm italic opacity-95">{c.tagline}</p>
      </div>

      <Block icon={Video} title="Career video">
        {!videoFetched && !videoLoading && (
          <button
            onClick={() => retryVideo()}
            className="mx-auto flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-primary-foreground"
          >
            ▶️ Video दिखाओ
          </button>
        )}
        {videoLoading && (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <p className="text-xs text-muted-foreground">Pandu Ram tumhare liye video बना रहा है… (पहली बार थोड़ा time lagta hai)</p>
          </div>
        )}
        {videoError && (
          <div className="py-4 text-center">
            <p className="text-xs text-muted-foreground">Video नहीं बन पाया — फिर कोशिश करें।</p>
            <button onClick={() => retryVideo()} className="mt-2 rounded-full bg-brand px-4 py-1.5 text-xs font-semibold text-primary-foreground">Retry</button>
          </div>
        )}
        {videoScript?.slides && Array.isArray(videoScript.slides) && videoScript.slides.length > 0 && (
          <VideoErrorBoundary>
            <CareerVideoPlayer careerName={c.name} slides={videoScript.slides} />
          </VideoErrorBoundary>
        )}
      </Block>

      <Block icon={Sparkles} title="Overview">
        <p className="text-sm leading-relaxed text-muted-foreground">{c.overview}</p>
      </Block>

      <Block icon={Sparkles} title="Skills you'll build">
        <div className="flex flex-wrap gap-2">
          {(c.skills ?? []).map((s) => <span key={s} className="rounded-full bg-accent/15 px-3 py-1 text-xs font-medium text-accent">{s}</span>)}
        </div>
      </Block>

      <Block icon={IndianRupee} title="Salary in India">
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-2xl bg-secondary p-3"><p className="text-muted-foreground">Entry</p><p className="mt-1 font-display text-sm font-bold">{c.salary?.entry}</p></div>
          <div className="rounded-2xl bg-secondary p-3"><p className="text-muted-foreground">Mid</p><p className="mt-1 font-display text-sm font-bold">{c.salary?.mid}</p></div>
          <div className="rounded-2xl bg-secondary p-3"><p className="text-muted-foreground">Senior</p><p className="mt-1 font-display text-sm font-bold">{c.salary?.senior}</p></div>
        </div>
      </Block>

      <Block icon={TrendingUp} title="Growth & demand">
        <p className="text-sm text-muted-foreground">{c.growth}</p>
      </Block>

      <Block icon={Map} title="Roadmap">
        <ol className="space-y-2">
          {(c.roadmap ?? []).map((r, i) => (
            <li key={i} className="flex items-start gap-3 rounded-2xl bg-card-soft p-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-brand text-xs font-bold text-primary-foreground">{i + 1}</span>
              <span className="text-sm font-medium">{r.step}</span>
            </li>
          ))}
        </ol>
      </Block>

      <Link to="/chat" className="mb-6 mt-5 flex items-center justify-center gap-2 rounded-2xl bg-accent py-3 text-sm font-semibold text-accent-foreground shadow-soft">
        <MessageCircle className="h-4 w-4" /> Ask Pandu Ram about {c.name}
      </Link>
    </div>
  );
}

function Block({ icon: Icon, title, children }: { icon: React.ComponentType<{ className?: string }>; title: string; children: React.ReactNode }) {
  return (
    <section className="mt-5">
      <div className="mb-2 flex items-center gap-2">
        <div className="grid h-7 w-7 place-items-center rounded-xl bg-accent/15 text-accent"><Icon className="h-3.5 w-3.5" /></div>
        <h2 className="font-display text-base font-semibold">{title}</h2>
      </div>
      <div className="rounded-3xl border border-border bg-card p-4">{children}</div>
    </section>
  );
}
