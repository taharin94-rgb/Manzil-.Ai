import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, LogOut, Globe, User, Bell, ShieldCheck, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings – Manzil AI" }] }),
  component: Settings,
});

const LANGUAGES = [
  "Hindi", "English", "Hinglish",
  "Marathi", "Tamil", "Telugu", "Bengali", "Gujarati", "Kannada", "Malayalam", "Punjabi", "Urdu",
];

function Settings() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: profile } = useQuery({
    queryKey: ["profile-settings"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      return (await supabase.from("profiles").select("full_name, language, class_level, board").eq("id", user.id).maybeSingle()).data;
    },
  });
  const [language, setLanguage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const currentLanguage = language ?? profile?.language ?? "English";

  async function changeLanguage(lang: string) {
    setLanguage(lang);
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return setSaving(false);
    const { error } = await supabase.from("profiles").update({ language: lang }).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["profile-settings"] });
    qc.invalidateQueries({ queryKey: ["profile"] });
    toast.success(`Language set to ${lang}`);
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate({ to: "/" });
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-6 pb-24">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <h1 className="mt-3 font-display text-3xl font-semibold">Settings</h1>
      <p className="text-sm text-muted-foreground">Manage your account and preferences.</p>

      <section className="mt-6 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Profile</h2>
        </div>
        <p className="mt-1 text-sm">{profile?.full_name ?? "—"}</p>
        <p className="text-xs text-muted-foreground">Class {profile?.class_level ?? "?"} · {profile?.board ?? "?"} board</p>
      </section>

      <section className="mt-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Language</h2>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Mr. Pandu Ram will chat with you in this language. Change it anytime.</p>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {LANGUAGES.map((lang) => (
            <button
              key={lang}
              disabled={saving}
              onClick={() => changeLanguage(lang)}
              className={
                "rounded-2xl border px-2 py-2.5 text-xs font-semibold transition disabled:opacity-50 " +
                (currentLanguage === lang ? "border-primary bg-primary/10 text-primary" : "border-border bg-card-soft text-foreground")
              }
            >
              {lang}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Notifications</h2>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Daily streak reminders show up right on your Home screen — no extra setup needed.</p>
      </section>

      <section className="mt-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Privacy</h2>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Mr. Pandu Ram only helps with studies & careers, and never asks for sensitive personal information.</p>
      </section>

      <Link to="/pricing" className="mt-4 flex items-center justify-between rounded-3xl border border-border bg-card p-4 shadow-soft">
        <span className="font-display text-base font-semibold">Manage subscription</span>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <button onClick={signOut} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-destructive/30 py-3 text-sm font-semibold text-destructive">
        <LogOut className="h-4 w-4" /> Log out
      </button>
    </div>
  );
}
