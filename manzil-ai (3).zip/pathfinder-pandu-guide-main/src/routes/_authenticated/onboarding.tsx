import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: "Set up – Manzil AI" }] }),
  component: Onboarding,
});

function Onboarding() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    full_name: "", age: "", gender: "",
    school_name: "", class_level: "10", board: "CBSE",
    city: "", language: "English", interests: "",
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { navigate({ to: "/auth" }); return; }
    const { error } = await supabase.from("profiles").upsert({
      id: user.id,
      full_name: form.full_name,
      age: form.age ? parseInt(form.age) : null,
      gender: form.gender || null,
      school_name: form.school_name || null,
      class_level: form.class_level,
      board: form.board,
      city: form.city || null,
      language: form.language,
      interests: form.interests ? form.interests.split(",").map((s) => s.trim()).filter(Boolean) : null,
      onboarded: true,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("All set! Let's discover your path.");
    navigate({ to: "/assessment" });
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-8">
      <div className="text-center">
        <PanduRam className="mx-auto h-24 w-24" />
        <h1 className="mt-3 font-display text-2xl font-semibold">Tell me about you</h1>
        <p className="text-sm text-muted-foreground">So I can guide you better.</p>
      </div>

      <form onSubmit={submit} className="mt-6 space-y-3">
        <Field label="Full name"><input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} className={inputCls} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Age"><input type="number" min="12" max="25" value={form.age} onChange={(e) => setForm({ ...form, age: e.target.value })} className={inputCls} /></Field>
          <Field label="Gender">
            <select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} className={inputCls}>
              <option value="">Prefer not to say</option><option>Female</option><option>Male</option><option>Other</option>
            </select>
          </Field>
        </div>
        <Field label="School name"><input value={form.school_name} onChange={(e) => setForm({ ...form, school_name: e.target.value })} className={inputCls} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Class">
            <select value={form.class_level} onChange={(e) => setForm({ ...form, class_level: e.target.value })} className={inputCls}>
              <option value="10">Class 10</option><option value="12">Class 12</option>
            </select>
          </Field>
          <Field label="Board">
            <select value={form.board} onChange={(e) => setForm({ ...form, board: e.target.value })} className={inputCls}>
              <option>CBSE</option><option>ICSE</option><option>State Board</option><option>IB</option><option>Other</option>
            </select>
          </Field>
        </div>
        <Field label="City"><input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className={inputCls} /></Field>
        <Field label="Preferred language">
          <select value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className={inputCls}>
            <option>Hindi</option><option>English</option><option>Hinglish</option>
            <option>Marathi</option><option>Tamil</option><option>Telugu</option><option>Bengali</option><option>Gujarati</option><option>Kannada</option><option>Malayalam</option><option>Punjabi</option><option>Urdu</option>
          </select>
        </Field>
        <Field label="Interests (comma separated)"><input placeholder="coding, music, sports" value={form.interests} onChange={(e) => setForm({ ...form, interests: e.target.value })} className={inputCls} /></Field>

        <button type="submit" disabled={busy} className="mt-4 w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60">
          {busy ? "Saving…" : "Continue"}
        </button>
      </form>
    </div>
  );
}

const inputCls = "w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
