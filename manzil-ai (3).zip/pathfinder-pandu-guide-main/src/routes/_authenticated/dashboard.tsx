import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";
import { ArrowRight, Sparkles, Compass, MessageCircle, Trophy, Crown, Copy, Users, Swords, Heart, Sparkle, Settings as SettingsIcon } from "lucide-react";
import { toast } from "sonner";
import { generateInviteCode } from "@/lib/invites.functions";
import { generateParentMessage } from "@/lib/parent-explain.functions";
import { generateDailyTasks, type DailyTask } from "@/lib/daily-tasks.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard – Manzil AI" }] }),
  component: Dashboard,
});

type Analysis = {
  stream?: string;
  top_careers?: { name: string; match: number; why: string }[];
  strengths?: string[];
};

function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const genCode = useServerFn(generateInviteCode);
  const genParentMsg = useServerFn(generateParentMessage);
  const [showInvite, setShowInvite] = useState<"parent" | "school" | null>(null);
  const [parentMsg, setParentMsg] = useState<string | null>(null);
  const [parentMsgLoading, setParentMsgLoading] = useState(false);

  const { data: profile, isLoading: pl } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => (await supabase.from("profiles").select("*").maybeSingle()).data,
  });
  const { data: assessment } = useQuery({
    queryKey: ["latest-assessment"],
    queryFn: async () => (await supabase.from("assessments").select("*").order("created_at", { ascending: false }).limit(1).maybeSingle()).data,
  });
  const { data: sub } = useQuery({
    queryKey: ["sub"],
    queryFn: async () => (await supabase.from("subscriptions").select("plan, status").maybeSingle()).data,
  });
  const { data: topGoal } = useQuery({
    queryKey: ["top-goal"],
    queryFn: async () => (await supabase.from("goals").select("id, title, progress, target_date, milestones, daily_tasks, created_at").order("created_at", { ascending: false }).limit(1).maybeSingle()).data,
  });
  const genDailyTasks = useServerFn(generateDailyTasks);
  const [generatingTasks, setGeneratingTasks] = useState(false);
  const [freshTasks, setFreshTasks] = useState<DailyTask[] | null>(null);

  useEffect(() => {
    const existing = (topGoal?.daily_tasks as DailyTask[] | null) ?? [];
    if (!topGoal || existing.length > 0 || generatingTasks || freshTasks) return;
    setGeneratingTasks(true);
    genDailyTasks({ data: { goalId: topGoal.id, careerName: topGoal.title } })
      .then((r) => setFreshTasks(r.tasks))
      .catch(() => undefined)
      .finally(() => setGeneratingTasks(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topGoal?.id]);
  const { data: streak } = useQuery({
    queryKey: ["streak"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const today = new Date().toISOString().slice(0, 10);
      const { data: existing } = await supabase.from("user_streaks").select("*").eq("user_id", user.id).maybeSingle();
      if (!existing) {
        const { data: inserted } = await supabase.from("user_streaks").insert({ user_id: user.id, streak_count: 1, last_active_date: today }).select().maybeSingle();
        return inserted;
      }
      if (existing.last_active_date === today) return existing;
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      const newCount = existing.last_active_date === yesterday ? existing.streak_count + 1 : 1;
      const { data: updated } = await supabase.from("user_streaks").update({ streak_count: newCount, last_active_date: today }).eq("user_id", user.id).select().maybeSingle();
      return updated;
    },
  });

  useEffect(() => {
    if (!pl && profile && !profile.onboarded) navigate({ to: "/onboarding" });
  }, [pl, profile, navigate]);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate({ to: "/" });
  }

  async function makeCode(intended: "parent" | "school") {
    try {
      const { code } = await genCode({ data: { intended_role: intended } });
      setShowInvite(intended);
      await navigator.clipboard.writeText(code).catch(() => undefined);
      toast.success(`Code ${code} copied — share it with your ${intended}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not generate");
    }
  }

  async function explainToParents() {
    const careerName = topGoal?.title || analysis?.top_careers?.[0]?.name;
    if (!careerName) return toast.error("Pehle Roadmap ya Assessment se ek career choose karo");
    setParentMsgLoading(true);
    setParentMsg(null);
    try {
      const { message } = await genParentMsg({ data: { careerName } });
      setParentMsg(message);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Message generate nahi ho paaya");
    } finally {
      setParentMsgLoading(false);
    }
  }

  const analysis = assessment?.analysis as Analysis | null;
  const done = assessment?.status === "completed" && analysis;
  const isPremium = sub && sub.plan !== "free" && sub.status === "active";
  const dailyTasks = freshTasks ?? ((Array.isArray(topGoal?.daily_tasks) ? topGoal.daily_tasks : []) as DailyTask[]);
  const daysSinceGoal = topGoal?.created_at ? Math.floor((Date.now() - new Date(topGoal.created_at).getTime()) / 86400000) : 0;
  const todaysTask = dailyTasks.length ? dailyTasks[daysSinceGoal % dailyTasks.length] : null;

  return (
    <div className="mx-auto max-w-md px-5 pt-8">
      <header className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Namaste 👋</p>
          <h1 className="font-display text-3xl font-semibold">{profile?.full_name?.split(" ")[0] || "Friend"}</h1>
        </div>
        <div className="flex gap-2">
          <Link to="/pricing" className={"grid h-10 w-10 place-items-center rounded-2xl border " + (isPremium ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-muted-foreground")} aria-label="Premium"><Crown className="h-4 w-4" /></Link>
          <Link to="/settings" className="grid h-10 w-10 place-items-center rounded-2xl border border-border bg-card text-muted-foreground" aria-label="Settings"><SettingsIcon className="h-4 w-4" /></Link>
        </div>
      </header>

      {(streak?.streak_count ?? 0) > 0 && (
        <div className="mt-4 rounded-3xl border border-border bg-card px-4 py-3 shadow-soft">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">🔥</span>
              <div>
                <p className="font-display text-sm font-semibold">{streak?.streak_count}-day streak</p>
                <p className="text-[10.5px] text-muted-foreground">Roz ek task karo, career ke paas pahuncho</p>
              </div>
            </div>
          </div>
          {generatingTasks && <p className="mt-2 text-[11px] text-muted-foreground">Pandu Ram tumhare liye daily tasks bana raha hai…</p>}
          {todaysTask && (
            <div className="mt-3 rounded-2xl bg-accent/10 p-3">
              <p className="text-[9.5px] font-bold uppercase tracking-wide text-accent">Aaj ka task</p>
              <p className="text-sm font-semibold">{todaysTask.title}</p>
              {todaysTask.detail && <p className="mt-0.5 text-[11px] text-muted-foreground">{todaysTask.detail}</p>}
            </div>
          )}
        </div>
      )}

      {!done ? (
        <Link to="/assessment" className="mt-6 block overflow-hidden rounded-3xl bg-brand p-5 text-primary-foreground shadow-pop">
          <div className="flex items-center gap-4">
            <PanduRam className="h-20 w-20 shrink-0" />
            <div className="min-w-0">
              <p className="text-xs uppercase tracking-wide opacity-80">Start here</p>
              <p className="font-display text-xl font-semibold leading-tight">Take your Career Discovery</p>
              <p className="mt-1 text-sm opacity-90">20 questions • 10 min • Personal results</p>
              <span className="mt-2 inline-flex items-center gap-1 text-sm font-semibold">Begin <ArrowRight className="h-4 w-4" /></span>
            </div>
          </div>
        </Link>
      ) : (
        <Link to="/results" className="mt-6 block rounded-3xl border border-border bg-card p-5 shadow-soft">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-success/15 text-success"><Trophy className="h-6 w-6" /></div>
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Your results</p>
              <p className="font-display text-lg font-semibold">{analysis?.stream} stream recommended</p>
            </div>
          </div>
          {analysis?.top_careers?.slice(0, 3).map((c) => (
            <div key={c.name} className="mt-3 flex items-center justify-between rounded-2xl bg-secondary px-3 py-2">
              <span className="text-sm font-medium">{c.name}</span>
              <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-bold text-primary">{c.match}%</span>
            </div>
          ))}
          <p className="mt-3 text-right text-sm font-semibold text-primary">View full report →</p>
        </Link>
      )}

      {topGoal && (
        <Link to="/roadmap" className="mt-4 block rounded-3xl border border-border bg-card p-4 shadow-soft">
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Roadmap</p>
              <p className="truncate font-display text-base font-semibold">{topGoal.title}</p>
              {topGoal.target_date && <p className="text-xs text-accent">🎯 Target {new Date(topGoal.target_date).getFullYear()}</p>}
            </div>
            <span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-bold text-primary">{topGoal.progress}%</span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary">
            <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${topGoal.progress}%` }} />
          </div>
        </Link>
      )}

      <h2 className="mt-8 font-display text-lg font-semibold">Quick actions</h2>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <QuickCard to="/chat" icon={MessageCircle} title="Ask Pandu Ram" subtitle="AI mentor + voice" tint="violet" />
        <QuickCard to="/explore" icon={Compass} title="Explore careers" subtitle="Find what fits you" tint="orange" />
        <QuickCard to="/roadmap" icon={Sparkles} title="My roadmap" subtitle="Set & track goals" tint="orange" />
        <QuickCard to="/battle" icon={Swords} title="Career Battle" subtitle="Compare 2 careers" tint="violet" />
        <QuickCard to="/prediction" icon={Sparkle} title="Career Prediction" subtitle="Future demand 🔮" tint="orange" />
        <QuickCard to="/pricing" icon={Crown} title={isPremium ? "Premium" : "Go Premium"} subtitle={isPremium ? "Active ✓" : "₹99 / month"} tint="violet" />
      </div>

      <section className="mt-8 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Invite parent</h2>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Generate a code so they can see your progress.</p>
        <button onClick={() => makeCode("parent")} className="mt-3 w-full rounded-2xl bg-accent/15 px-3 py-2.5 text-xs font-semibold text-accent">Generate code for parent</button>
        {showInvite === "parent" && <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground"><Copy className="h-3 w-3" /> Code copied. Share with your parent.</p>}
      </section>

      <section className="mt-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <Heart className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base font-semibold">Parents ko samjhao 💬</h2>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">AI ek respectful message banayega jo tum apne parents ko dikha sakte ho — tumhare career choice ke baare mein.</p>
        <button onClick={explainToParents} disabled={parentMsgLoading} className="mt-3 w-full rounded-2xl bg-brand px-3 py-2.5 text-xs font-semibold text-primary-foreground disabled:opacity-50">
          {parentMsgLoading ? "AI likh raha hai…" : "✨ Message banao"}
        </button>
        {parentMsg && (
          <div className="mt-3 rounded-2xl bg-card-soft p-3">
            <p className="whitespace-pre-line text-xs leading-relaxed">{parentMsg}</p>
            <button
              onClick={() => { navigator.clipboard.writeText(parentMsg); toast.success("Copy ho gaya!"); }}
              className="mt-2 flex items-center gap-1 text-[11px] font-semibold text-primary"
            >
              <Copy className="h-3 w-3" /> Copy karo
            </button>
          </div>
        )}
      </section>
    </div>
  );
}

function QuickCard({ to, icon: Icon, title, subtitle, tint }: { to: string; icon: React.ComponentType<{ className?: string }>; title: string; subtitle: string; tint: "orange" | "violet" }) {
  return (
    <Link to={to} className="rounded-3xl border border-border bg-card p-4 shadow-soft transition active:scale-[0.98]">
      <div className={"grid h-10 w-10 place-items-center rounded-2xl " + (tint === "violet" ? "bg-accent/15 text-accent" : "bg-primary/15 text-primary")}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="mt-3 font-display text-base font-semibold">{title}</p>
      <p className="text-xs text-muted-foreground">{subtitle}</p>
    </Link>
  );
}
