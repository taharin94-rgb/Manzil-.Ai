import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Swords, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { compareCareers, type BattleResult } from "@/lib/battle.functions";

export const Route = createFileRoute("/_authenticated/battle")({
  head: () => ({ meta: [{ title: "Career Battle – Manzil AI" }] }),
  component: Battle,
});

type CareerOption = { slug: string; name: string; emoji: string | null };

function Battle() {
  const runCompare = useServerFn(compareCareers);
  const { data: careers = [] } = useQuery<CareerOption[]>({
    queryKey: ["careers-picker"],
    queryFn: async () => (await supabase.from("careers").select("slug, name, emoji").order("name")).data as CareerOption[] ?? [],
  });

  const [aSlug, setASlug] = useState("");
  const [bSlug, setBSlug] = useState("");
  const [aSearch, setASearch] = useState("");
  const [bSearch, setBSearch] = useState("");
  const [result, setResult] = useState<(BattleResult & { careerAName: string; careerBName: string }) | null>(null);
  const [loading, setLoading] = useState(false);

  const aList = careers.filter((c) => c.slug !== bSlug && c.name.toLowerCase().includes(aSearch.toLowerCase()));
  const bList = careers.filter((c) => c.slug !== aSlug && c.name.toLowerCase().includes(bSearch.toLowerCase()));

  async function fight() {
    if (!aSlug || !bSlug) return toast.error("Dono careers pick karo pehle");
    setLoading(true);
    setResult(null);
    try {
      const r = await runCompare({ data: { careerASlug: aSlug, careerBSlug: bSlug } });
      setResult(r);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Comparison generate nahi ho paaya");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-6 pb-24">
      <div className="flex items-center gap-2">
        <Swords className="h-6 w-6 text-accent" />
        <h1 className="font-display text-3xl font-semibold">Career Battle</h1>
      </div>
      <p className="text-sm text-muted-foreground">Do careers ko aamne-saamne compare karo — honest, no hype.</p>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <CareerPicker label="Career A" slug={aSlug} setSlug={setASlug} search={aSearch} setSearch={setASearch} options={aList} />
        <CareerPicker label="Career B" slug={bSlug} setSlug={setBSlug} search={bSearch} setSearch={setBSearch} options={bList} />
      </div>

      <button
        onClick={fight}
        disabled={!aSlug || !bSlug || loading}
        className="mt-4 w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-pop disabled:opacity-50"
      >
        {loading ? "AI comparison बना रहा है…" : "⚔️ Compare करो"}
      </button>

      {result && (
        <div className="mt-6 space-y-4">
          <div className="rounded-3xl border border-border bg-card p-4 shadow-soft">
            <p className="text-sm text-muted-foreground">{result.summary}</p>
          </div>

          <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
            <div className="grid grid-cols-3 gap-1 bg-brand p-3 text-center text-xs font-semibold text-primary-foreground">
              <span></span>
              <span className="truncate">{result.careerAName}</span>
              <span className="truncate">{result.careerBName}</span>
            </div>
            {result.rows.map((row, i) => (
              <div key={i} className={"grid grid-cols-3 gap-1 border-t border-border p-3 text-xs " + (i % 2 === 0 ? "bg-card" : "bg-card-soft")}>
                <span className="font-semibold text-muted-foreground">{row.label}</span>
                <span className={row.winner === "a" ? "font-bold text-primary" : ""}>{row.winner === "a" && "🏆 "}{row.a}</span>
                <span className={row.winner === "b" ? "font-bold text-primary" : ""}>{row.winner === "b" && "🏆 "}{row.b}</span>
              </div>
            ))}
          </div>

          <div className="rounded-3xl bg-accent/10 p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-accent">Verdict</p>
            <p className="mt-1 text-sm">{result.verdict}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function CareerPicker({
  label, slug, setSlug, search, setSearch, options,
}: {
  label: string; slug: string; setSlug: (s: string) => void; search: string; setSearch: (s: string) => void; options: CareerOption[];
}) {
  const selected = options.find((o) => o.slug === slug);
  return (
    <div className="rounded-3xl border border-border bg-card p-3 shadow-soft">
      <label className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>
      {slug ? (
        <button onClick={() => setSlug("")} className="mt-2 w-full rounded-2xl bg-primary/10 p-2 text-left text-xs font-semibold text-primary">
          {selected?.emoji} {selected?.name ?? slug} ✕
        </button>
      ) : (
        <>
          <label className="mt-2 flex items-center gap-1 rounded-full border border-input bg-card-soft px-2 py-1.5">
            <Search className="h-3 w-3 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search…" className="w-full bg-transparent text-[11px] outline-none" />
          </label>
          <div className="mt-1 max-h-32 space-y-0.5 overflow-y-auto">
            {options.slice(0, 30).map((c) => (
              <button key={c.slug} onClick={() => setSlug(c.slug)} className="block w-full truncate rounded-xl px-2 py-1.5 text-left text-[11px] hover:bg-secondary">
                {c.emoji} {c.name}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
