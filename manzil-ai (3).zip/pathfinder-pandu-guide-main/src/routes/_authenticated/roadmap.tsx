import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { CheckCircle2, Circle, Plus, Target, Trash2, Sparkles, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { generateRoadmap, type GeneratedMilestone } from "@/lib/roadmap.functions";

export const Route = createFileRoute("/_authenticated/roadmap")({
  head: () => ({ meta: [{ title: "My roadmap – Manzil AI" }] }),
  component: Roadmap,
});

type Milestone = GeneratedMilestone;
type Goal = {
  id: string;
  title: string;
  description: string | null;
  target_date: string | null;
  progress: number;
  milestones: Milestone[];
};
type CareerOption = { slug: string; name: string; emoji: string | null };

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 12 }, (_, i) => CURRENT_YEAR + i);

function progressFrom(ms: Milestone[]): number {
  if (!ms.length) return 0;
  return Math.round((ms.filter((m) => m.done).length / ms.length) * 100);
}

function Roadmap() {
  const qc = useQueryClient();
  const runGenerateRoadmap = useServerFn(generateRoadmap);
  const [picking, setPicking] = useState(false);
  const [search, setSearch] = useState("");
  const [slug, setSlug] = useState<string>("");
  const [careerName, setCareerName] = useState<string>("");
  const [year, setYear] = useState<number>(CURRENT_YEAR + 4);
  const [creating, setCreating] = useState(false);

  const { data: goals = [], isLoading } = useQuery<Goal[]>({
    queryKey: ["goals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("goals")
        .select("id, title, description, target_date, progress, milestones")
        .order("created_at", { ascending: false });
      if (error) {
        toast.error(`Couldn't load your roadmaps: ${error.message}`);
        throw error;
      }
      return ((data ?? []) as unknown as Goal[]).map((g) => ({
        ...g,
        milestones: Array.isArray(g.milestones) ? g.milestones : [],
      }));
    },
  });

  const { data: careers = [] } = useQuery<CareerOption[]>({
    queryKey: ["careers-picker"],
    queryFn: async () => (await supabase.from("careers").select("slug, name, emoji").order("name")).data as CareerOption[] ?? [],
    enabled: picking,
  });
  const filteredCareers = careers.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));

  async function createRoadmap() {
    if (creating) return;
    if (!slug) return toast.error("Pick a career first");
    setCreating(true);
    try {
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError) return toast.error(`Session error: ${authError.message}. Try logging in again.`);
      if (!user) return toast.error("You're not signed in — please log in again and retry.");

      const generated = await runGenerateRoadmap({ data: { careerSlug: slug, targetYear: year } });

      const { error } = await supabase.from("goals").insert({
        user_id: user.id,
        title: careerName,
        description: generated.description || null,
        target_date: `${year}-06-01`,
        progress: 0,
        milestones: generated.milestones as never,
      });
      if (error) return toast.error(`Couldn't save roadmap: ${error.message}`);
      toast.success("Personalized roadmap ready! 🎉");
      setPicking(false);
      setSlug("");
      setCareerName("");
      setSearch("");
      qc.invalidateQueries({ queryKey: ["goals"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Roadmap generate nahi ho paaya — phir try karein");
    } finally {
      setCreating(false);
    }
  }

  async function toggleMilestone(goal: Goal, id: string) {
    const updated = goal.milestones.map((m) => (m.id === id ? { ...m, done: !m.done } : m));
    const progress = progressFrom(updated);
    const { error } = await supabase
      .from("goals")
      .update({ milestones: updated as never, progress })
      .eq("id", goal.id);
    if (error) return toast.error(error.message);
    qc.setQueryData<Goal[]>(["goals"], (prev = []) =>
      prev.map((g) => (g.id === goal.id ? { ...g, milestones: updated, progress } : g)),
    );
  }

  async function remove(id: string) {
    const { error } = await supabase.from("goals").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["goals"] });
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-6 pb-24">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">My roadmap</h1>
          <p className="text-sm text-muted-foreground">Pick a career, hit every milestone.</p>
        </div>
        {!picking && (
          <button onClick={() => setPicking(true)} className="flex items-center gap-1 rounded-full bg-brand px-4 py-2 text-xs font-semibold text-primary-foreground shadow-soft">
            <Plus className="h-4 w-4" /> New
          </button>
        )}
      </div>

      {picking && (
        <div className="mt-5 space-y-4 rounded-3xl border border-border bg-card p-4 shadow-soft">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Career goal</label>
            <label className="mt-2 flex items-center gap-2 rounded-full border border-input bg-card-soft px-3 py-2">
              <Search className="h-3.5 w-3.5 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={`Search ${careers.length || "78+"} careers…`}
                className="w-full bg-transparent text-sm outline-none"
              />
            </label>
            <div className="mt-2 grid max-h-52 grid-cols-2 gap-2 overflow-y-auto pr-1">
              {filteredCareers.map((c) => (
                <button
                  key={c.slug}
                  onClick={() => { setSlug(c.slug); setCareerName(c.name); }}
                  className={"rounded-2xl border p-3 text-left text-xs font-semibold transition " + (slug === c.slug ? "border-primary bg-primary/10 text-primary" : "border-border bg-card-soft text-foreground")}
                >
                  <div className="text-lg">{c.emoji}</div>
                  {c.name}
                </button>
              ))}
              {careers.length > 0 && filteredCareers.length === 0 && (
                <p className="col-span-2 py-4 text-center text-xs text-muted-foreground">Koi match nahi mila</p>
              )}
            </div>
          </div>

          {slug && (
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Target year</label>
              <select
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="mt-2 w-full rounded-2xl border border-input bg-background px-4 py-2.5 text-sm"
              >
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
          )}

          <div className="flex gap-2">
            <button onClick={() => { setPicking(false); setSlug(""); setSearch(""); }} className="flex-1 rounded-2xl border border-border py-2.5 text-sm font-semibold">Cancel</button>
            <button onClick={createRoadmap} disabled={!slug || creating} className="flex-1 rounded-2xl bg-brand py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50">
              {creating ? "AI बना रहा है…" : "Create roadmap"}
            </button>
          </div>
          {creating && <p className="text-center text-[11px] text-muted-foreground">Pandu Ram tumhare liye personalized roadmap likh raha hai — 10-15 second lagenge…</p>}
        </div>
      )}

      {isLoading && <p className="mt-6 text-center text-sm text-muted-foreground">Loading…</p>}

      <div className="mt-5 space-y-4">
        {!isLoading && goals.length === 0 && !picking && (
          <div className="rounded-3xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            <Target className="mx-auto mb-2 h-8 w-8 text-accent" />
            No roadmap yet. Tap <span className="font-semibold text-foreground">New</span> to pick a career ✨
          </div>
        )}

        {goals.map((g) => (
          <div key={g.id} className="rounded-3xl border border-border bg-card p-4 shadow-soft">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-display text-lg font-semibold">{g.title}</p>
                {g.description && <p className="text-xs text-muted-foreground">{g.description}</p>}
                {g.target_date && <p className="mt-0.5 text-xs text-accent">🎯 Target: {new Date(g.target_date).getFullYear()}</p>}
              </div>
              <button onClick={() => remove(g.id)} className="text-muted-foreground hover:text-destructive" aria-label="Delete">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-semibold text-primary">{g.progress}%</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-secondary">
                <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${g.progress}%` }} />
              </div>
            </div>

            {g.milestones.length > 0 ? (
              <ol className="mt-4 space-y-1">
                {g.milestones.map((m, i) => (
                  <li key={m.id}>
                    <button
                      onClick={() => toggleMilestone(g, m.id)}
                      className="flex w-full items-start gap-2 rounded-2xl px-2 py-2 text-left text-sm hover:bg-secondary"
                    >
                      {m.done ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success" /> : <Circle className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />}
                      <span className={m.done ? "line-through text-muted-foreground" : ""}>
                        <span className="mr-1 text-xs font-bold text-accent">{i + 1}.</span>{m.title}
                        {m.detail && <span className="mt-0.5 block text-xs font-normal text-muted-foreground">{m.detail}</span>}
                      </span>
                    </button>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="mt-3 flex items-center gap-1 text-xs text-muted-foreground"><Sparkles className="h-3 w-3" /> Custom goal — no milestones</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
