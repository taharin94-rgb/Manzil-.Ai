import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ASSESSMENT_QUESTIONS } from "@/lib/questions";
import { analyzeAssessment } from "@/lib/assessment.functions";
import { PanduRam } from "@/components/PanduRam";
import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/assessment")({
  head: () => ({ meta: [{ title: "Career Assessment – Manzil AI" }] }),
  component: Assessment,
});

function Assessment() {
  const navigate = useNavigate();
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<string[]>(Array(ASSESSMENT_QUESTIONS.length).fill(""));
  const [submitting, setSubmitting] = useState(false);
  const run = useServerFn(analyzeAssessment);

  const total = ASSESSMENT_QUESTIONS.length;
  const q = ASSESSMENT_QUESTIONS[idx];
  const answer = answers[idx];
  const progress = ((idx + (answer.trim() ? 1 : 0)) / total) * 100;

  function next() {
    if (!answer.trim()) return toast.error("Please share your answer first");
    if (idx < total - 1) setIdx(idx + 1);
  }

  async function finish() {
    if (!answer.trim()) return toast.error("Please share your answer first");
    setSubmitting(true);
    try {
      const result = await run({ data: { answers } });
      toast.success("Analysis ready!");
      navigate({ to: "/results", search: { id: result.id } });
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Could not analyze");
      setSubmitting(false);
    }
  }

  if (submitting) {
    return (
      <div className="mx-auto grid min-h-[80vh] max-w-md place-items-center px-5">
        <div className="text-center">
          <PanduRam className="mx-auto h-32 w-32 animate-pulse" />
          <h2 className="mt-4 font-display text-2xl font-semibold">Thinking…</h2>
          <p className="mt-1 text-sm text-muted-foreground">Mr. Pandu Ram is reading your answers and crafting your personalized career map.</p>
          <Loader2 className="mx-auto mt-6 h-6 w-6 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-6">
      <div className="flex items-center gap-3">
        <button onClick={() => idx > 0 ? setIdx(idx - 1) : navigate({ to: "/dashboard" })} className="grid h-9 w-9 place-items-center rounded-2xl border border-border bg-card" aria-label="Back">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="flex-1">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Question {idx + 1} of {total}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
            <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>

      <div className="mt-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-accent">Mr. Pandu Ram asks</p>
        <h2 className="mt-2 text-balance font-display text-2xl font-semibold leading-snug">{q}</h2>
        <textarea
          value={answer}
          onChange={(e) => setAnswers(answers.map((a, i) => (i === idx ? e.target.value : a)))}
          rows={6}
          placeholder="Type your answer in your own words…"
          className="mt-5 w-full rounded-3xl border border-input bg-card p-4 text-[15px] outline-none ring-ring/30 focus:ring-2"
        />
      </div>

      {idx < total - 1 ? (
        <button onClick={next} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft">
          Next <ArrowRight className="h-4 w-4" />
        </button>
      ) : (
        <button onClick={finish} className="mt-6 w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-pop">
          See my results ✨
        </button>
      )}
    </div>
  );
}
