import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, ArrowRight, Plus, LogOut } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/parent")({
  head: () => ({ meta: [{ title: "Parent dashboard – Manzil AI" }] }),
  component: ParentDashboard,
});

type Linked = {
  student_id: string;
  profile: { full_name: string | null; class_level: string | null; city: string | null } | null;
  assessment: { stream: string | null; top: { name: string; match: number }[] } | null;
  goals: number;
};

function ParentDashboard() {
  const { data: students = [], isLoading } = useQuery<Linked[]>({
    queryKey: ["parent-students"],
    queryFn: async () => {
      const { data: links } = await supabase.from("parent_students").select("student_id");
      if (!links?.length) return [];
      const ids = links.map((l) => l.student_id);
      const [{ data: profiles }, { data: assessments }, { data: goals }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, class_level, city").in("id", ids),
        supabase.from("assessments").select("user_id, analysis, status, created_at").in("user_id", ids).eq("status", "completed").order("created_at", { ascending: false }),
        supabase.from("goals").select("user_id").in("user_id", ids),
      ]);
      return ids.map((id) => {
        const profile = profiles?.find((p) => p.id === id) ?? null;
        const latest = assessments?.find((a) => a.user_id === id);
        const an = (latest?.analysis as { stream?: string; top_careers?: { name: string; match: number }[] } | undefined) ?? undefined;
        return {
          student_id: id,
          profile,
          assessment: an ? { stream: an.stream ?? null, top: (an.top_careers ?? []).slice(0, 3) } : null,
          goals: (goals ?? []).filter((g) => g.user_id === id).length,
        };
      });
    },
  });

  async function signOut() {
    await supabase.auth.signOut();
    toast.success("Signed out");
    window.location.href = "/";
  }

  return (
    <div className="mx-auto max-w-md px-5 pt-8">
      <header className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Parent Portal</p>
          <h1 className="font-display text-3xl font-semibold">Your children</h1>
        </div>
        <button onClick={signOut} className="grid h-10 w-10 place-items-center rounded-2xl border border-border bg-card text-muted-foreground"><LogOut className="h-4 w-4" /></button>
      </header>

      <Link to="/redeem" className="mt-5 flex items-center justify-between rounded-3xl bg-accent/10 p-4 text-accent-foreground">
        <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-2xl bg-accent text-accent-foreground"><Plus className="h-5 w-5" /></div><div><p className="font-display text-base font-semibold text-foreground">Link another child</p><p className="text-xs text-muted-foreground">Enter their invite code</p></div></div>
        <ArrowRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <div className="mt-5 space-y-4">
        {isLoading && <div className="rounded-3xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">Loading…</div>}
        {!isLoading && students.length === 0 && (
          <div className="rounded-3xl border border-dashed border-border p-8 text-center">
            <Users className="mx-auto mb-2 h-8 w-8 text-accent" />
            <p className="text-sm text-muted-foreground">No children linked yet. Tap "Link another child" above.</p>
          </div>
        )}
        {students.map((s) => (
          <div key={s.student_id} className="rounded-3xl border border-border bg-card p-5 shadow-soft">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-display text-lg font-semibold">{s.profile?.full_name ?? "Student"}</p>
                <p className="text-xs text-muted-foreground">Class {s.profile?.class_level ?? "—"} • {s.profile?.city ?? ""}</p>
              </div>
              {s.assessment?.stream && <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-bold text-primary">{s.assessment.stream}</span>}
            </div>
            {s.assessment?.top.length ? (
              <div className="mt-3 space-y-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Top career matches</p>
                {s.assessment.top.map((c) => (
                  <div key={c.name} className="flex items-center justify-between rounded-2xl bg-secondary px-3 py-2">
                    <span className="text-sm font-medium">{c.name}</span>
                    <span className="text-xs font-bold text-primary">{c.match}%</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 rounded-2xl bg-secondary p-3 text-xs text-muted-foreground">Assessment not completed yet.</p>
            )}
            <p className="mt-3 text-xs text-muted-foreground">Active goals: <span className="font-semibold text-foreground">{s.goals}</span></p>
          </div>
        ))}
      </div>
    </div>
  );
}
