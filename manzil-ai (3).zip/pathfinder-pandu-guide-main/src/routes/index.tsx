import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Compass, MessageCircle, Target, Swords, Video, Heart, Flame } from "lucide-react";
import { PanduRam } from "@/components/PanduRam";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Manzil AI – Your AI career mentor" },
      { name: "description", content: "Discover your ideal career with a personalized AI assessment, roadmap, and mentor — for every student, at every stage." },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { icon: Sparkles, t: "AI Career Match", d: "A personalized assessment ranks your best-fit careers with match scores." },
  { icon: Compass, t: "Explore 78+ Careers", d: "Real salaries, skills, growth outlook, and an AI-narrated video for every career." },
  { icon: Target, t: "Personalized Roadmap", d: "A step-by-step, AI-built plan around your class, interests, and goals." },
  { icon: MessageCircle, t: "Mr. Pandu Ram", d: "Chat anytime, by text or voice, with your friendly AI mentor." },
  { icon: Swords, t: "Career Battle", d: "Compare any two careers head-to-head — salary, demand, difficulty & more." },
  { icon: Video, t: "Career Prediction", d: "See how much future demand a career is likely to have, honestly forecast." },
  { icon: Flame, t: "Daily Streak & Tasks", d: "A small, focused task every day, tailored to the career you're chasing." },
  { icon: Heart, t: "Family Support", d: "Generate a message to help your parents understand your career choice." },
];

function Landing() {
  return (
    <main className="min-h-screen bg-warm">
      <div className="mx-auto max-w-md px-5 pb-16 pt-10">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-2xl bg-brand text-primary-foreground shadow-soft">
              <Sparkles className="h-5 w-5" />
            </div>
            <span className="font-display text-lg font-semibold">Manzil AI</span>
          </div>
          <Link to="/auth" className="text-sm font-medium text-foreground/70 hover:text-foreground">
            Sign in
          </Link>
        </header>

        <section className="mt-8 text-center">
          <PanduRam className="mx-auto h-44 w-44" priority />
          <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
            <Sparkles className="h-3.5 w-3.5" /> Meet Mr. Pandu Ram
          </div>
          <h1 className="mt-4 text-balance font-display text-[2.6rem] leading-[1.05] font-semibold">
            Find your <span className="text-primary">Manzil</span>.
          </h1>
          <p className="mt-3 text-balance text-[15px] text-muted-foreground">
            A complete AI career companion — for students at any stage. Discover your path,
            build your roadmap, and get guided every step of the way.
          </p>

          <Link
            to="/auth"
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-brand px-6 py-3.5 text-[15px] font-semibold text-primary-foreground shadow-pop transition hover:opacity-95"
          >
            Start your journey <ArrowRight className="h-4 w-4" />
          </Link>
          <p className="mt-2 text-xs text-muted-foreground">Free to start • No credit card</p>
        </section>

        <section className="mt-12 grid gap-3">
          {FEATURES.map(({ icon: Icon, t, d }) => (
            <div key={t} className="flex items-start gap-3 rounded-3xl border border-border bg-card-soft p-4 shadow-soft">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <p className="font-display text-base font-semibold">{t}</p>
                <p className="text-sm text-muted-foreground">{d}</p>
              </div>
            </div>
          ))}
        </section>

        <p className="mt-12 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Manzil AI • Your path to the right career
        </p>
      </div>
    </main>
  );
}
