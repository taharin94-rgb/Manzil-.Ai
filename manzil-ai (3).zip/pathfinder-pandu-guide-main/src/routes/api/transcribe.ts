import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/transcribe")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) return new Response("AI not configured", { status: 500 });

        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof Blob) || file.size === 0) {
          return new Response("No audio uploaded", { status: 400 });
        }
        if (file.size > 10 * 1024 * 1024) {
          return new Response("Audio too large (max 10 MB)", { status: 413 });
        }

        const mime = (file.type || "audio/webm").split(";")[0];
        const bytes = new Uint8Array(await file.arrayBuffer());
        let binary = "";
        for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
        const base64Audio = btoa(binary);

        const resp = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [
                {
                  role: "user",
                  parts: [
                    { text: "Transcribe this audio exactly as spoken. Return only the transcript text, nothing else." },
                    { inline_data: { mime_type: mime, data: base64Audio } },
                  ],
                },
              ],
            }),
          },
        );
        if (!resp.ok) {
          const txt = await resp.text().catch(() => "");
          return new Response(`Transcription failed: ${txt || resp.status}`, { status: resp.status });
        }
        const body = await resp.json();
        const text: string =
          body.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
        return Response.json({ text });
      },
    },
  },
});
