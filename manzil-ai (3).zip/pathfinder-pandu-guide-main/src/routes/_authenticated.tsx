import { createFileRoute, Outlet, useNavigate, useLocation } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { BottomNav } from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  component: AuthLayout,
});

const ROLE_HOME: Record<string, string> = { parent: "/parent", school: "/school", admin: "/admin" };

function AuthLayout() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const { data: roles } = useQuery({
    queryKey: ["roles", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("user_roles").select("role")).data?.map((r) => r.role) ?? [],
  });

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  // Auto-route parent/school users away from /dashboard to their portal
  useEffect(() => {
    if (!roles) return;
    if (pathname === "/dashboard") {
      const primary = roles.find((r) => r === "parent") ?? roles.find((r) => r === "school");
      if (primary) navigate({ to: ROLE_HOME[primary] });
    }
  }, [roles, pathname, navigate]);

  if (loading || !user) {
    return (
      <div className="grid min-h-screen place-items-center bg-warm">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  const hideNav = pathname.startsWith("/parent") || pathname.startsWith("/school") || pathname.startsWith("/admin") || pathname === "/redeem" || pathname === "/onboarding";

  return (
    <div className={"min-h-screen bg-warm " + (hideNav ? "" : "pb-24")}>
      <Outlet />
      {!hideNav && <BottomNav />}
    </div>
  );
}
