import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in – Manzil AI" },
      { name: "description", content: "Sign in or create your Manzil AI account." },
    ],
  }),
  component: AuthPage,
});

type Role = "student" | "parent" | "school";
type Method = "email" | "phone";

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [role, setRole] = useState<Role>("student");
  const [method, setMethod] = useState<Method>("email");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) routeAfterAuth();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function routeAfterAuth() {
    const target = role === "parent" || role === "school" ? "/redeem" : "/dashboard";
    navigate({ to: target });
  }

  async function handleEmail(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: name, intended_role: role }, emailRedirectTo: window.location.origin + "/auth" },
        });
        if (error) throw error;
        toast.success("Account created!");
        routeAfterAuth();
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        routeAfterAuth();
      }
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Auth failed");
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setBusy(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin + "/auth" },
    });
    if (error) {
      toast.error(error.message || "Google sign-in failed");
      setBusy(false);
      return;
    }
    // Supabase redirects the browser to Google automatically; no further
    // action needed here — routeAfterAuth() runs on return via the
    // getSession() check in useEffect above.
  }

  async function sendOtp() {
    if (!phone) return toast.error("Enter your phone with country code");
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({ phone });
      if (error) throw error;
      setOtpSent(true);
      toast.success("OTP sent");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not send OTP. Phone provider may be disabled.");
    } finally {
      setBusy(false);
    }
  }

  async function verifyOtp() {
    setBusy(true);
    try {
      const { error } = await supabase.auth.verifyOtp({ phone, token: otp, type: "sms" });
      if (error) throw error;
      toast.success("Signed in!");
      routeAfterAuth();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Wrong OTP");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-warm">
      <div className="mx-auto max-w-md px-5 py-8">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>

        <div className="mt-4 text-center">
          <PanduRam className="mx-auto h-24 w-24" />
          <h1 className="mt-3 font-display text-3xl font-semibold">
            {mode === "signup" ? "Let's get started" : "Welcome back"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === "signup" ? "Mr. Pandu Ram is excited to meet you." : "Mr. Pandu Ram missed you."}
          </p>
        </div>

        {mode === "signup" && (
          <div className="mt-5 grid grid-cols-3 gap-2 rounded-2xl bg-card p-1.5 text-xs font-semibold">
            {(["student", "parent", "school"] as Role[]).map((r) => (
              <button key={r} onClick={() => setRole(r)} className={"rounded-xl py-2 capitalize " + (role === r ? "bg-brand text-primary-foreground shadow-soft" : "text-muted-foreground")}>{r}</button>
            ))}
          </div>
        )}

        <div className="mt-4 rounded-3xl border border-border bg-card p-5 shadow-soft">
          <button
            onClick={handleGoogle}
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-background py-3 text-sm font-semibold transition hover:bg-secondary disabled:opacity-50"
          >
            <GoogleIcon /> Continue with Google
          </button>

          <div className="mt-4 grid grid-cols-2 gap-2 rounded-2xl bg-secondary p-1 text-xs font-semibold">
            <button onClick={() => setMethod("email")} className={"rounded-xl py-2 " + (method === "email" ? "bg-background shadow-soft" : "text-muted-foreground")}>Email</button>
            <button onClick={() => setMethod("phone")} className={"rounded-xl py-2 " + (method === "phone" ? "bg-background shadow-soft" : "text-muted-foreground")}>Phone OTP</button>
          </div>

          {method === "email" ? (
            <form onSubmit={handleEmail} className="mt-4 space-y-3">
              {mode === "signup" && (
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required className={inputCls} />
              )}
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required className={inputCls} />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required minLength={6} className={inputCls} />
              <button type="submit" disabled={busy} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft transition disabled:opacity-60">
                {busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"}
              </button>
              {mode === "signin" && (
                <Link to="/forgot-password" className="block text-center text-xs text-muted-foreground hover:text-foreground">
                  Forgot your password?
                </Link>
              )}
            </form>
          ) : (
            <div className="mt-4 space-y-3">
              <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 9XXXXXXXXX" className={inputCls} />
              {!otpSent ? (
                <button onClick={sendOtp} disabled={busy} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60">{busy ? "Sending…" : "Send OTP"}</button>
              ) : (
                <>
                  <input value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="6-digit OTP" inputMode="numeric" maxLength={6} className={inputCls} />
                  <button onClick={verifyOtp} disabled={busy || otp.length < 6} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60">{busy ? "Verifying…" : "Verify & sign in"}</button>
                </>
              )}
              <p className="text-center text-[11px] text-muted-foreground">SMS provider must be enabled by the workspace owner.</p>
            </div>
          )}

          <button
            onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
            className="mt-4 w-full text-center text-sm text-muted-foreground hover:text-foreground"
          >
            {mode === "signup" ? "Have an account? Sign in" : "New here? Create account"}
          </button>
        </div>
      </div>
    </main>
  );
}

const inputCls = "w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2";

function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.83z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/></svg>
  );
}
