import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [{ title: "Reset password – Manzil AI" }] }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Supabase delivers a recovery session via the URL hash on landing.
    supabase.auth.getSession().then(({ data }) => setReady(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) return toast.error("Password must be at least 6 characters");
    if (password !== confirm) return toast.error("Passwords don't match");
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      toast.success("Password updated — you're signed in!");
      navigate({ to: "/dashboard" });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not update password");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-warm">
      <div className="mx-auto max-w-md px-5 py-8">
        <div className="mt-4 text-center">
          <PanduRam className="mx-auto h-24 w-24" />
          <h1 className="mt-3 font-display text-3xl font-semibold">Set a new password</h1>
          <p className="mt-1 text-sm text-muted-foreground">Choose a strong password you'll remember.</p>
        </div>

        <div className="mt-4 rounded-3xl border border-border bg-card p-5 shadow-soft">
          {!ready ? (
            <div className="text-center text-sm">
              <p className="text-muted-foreground">This page only works from the reset link in your email.</p>
              <Link to="/forgot-password" className="mt-4 inline-block rounded-2xl bg-brand px-5 py-2.5 text-sm font-semibold text-primary-foreground">Request a new link</Link>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-3">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="New password"
                required
                minLength={6}
                className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2"
              />
              <input
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="Confirm new password"
                required
                minLength={6}
                className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2"
              />
              <button type="submit" disabled={busy} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60">
                {busy ? "Updating…" : "Update password"}
              </button>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}
