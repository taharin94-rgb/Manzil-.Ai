import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PanduRam } from "@/components/PanduRam";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({ meta: [{ title: "Forgot password – Manzil AI" }] }),
  component: ForgotPassword,
});

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + "/reset-password",
      });
      if (error) throw error;
      setSent(true);
      toast.success("Reset link sent — check your email");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not send reset link");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-warm">
      <div className="mx-auto max-w-md px-5 py-8">
        <Link to="/auth" className="inline-flex items-center gap-1 text-sm text-muted-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to sign in
        </Link>
        <div className="mt-4 text-center">
          <PanduRam className="mx-auto h-24 w-24" />
          <h1 className="mt-3 font-display text-3xl font-semibold">Forgot password?</h1>
          <p className="mt-1 text-sm text-muted-foreground">No worries — we'll email you a reset link.</p>
        </div>

        <div className="mt-4 rounded-3xl border border-border bg-card p-5 shadow-soft">
          {sent ? (
            <div className="text-center text-sm">
              <p className="font-semibold">Check your inbox</p>
              <p className="mt-1 text-muted-foreground">We sent a password reset link to <span className="font-medium text-foreground">{email}</span>.</p>
              <Link to="/auth" className="mt-4 inline-block rounded-2xl bg-brand px-5 py-2.5 text-sm font-semibold text-primary-foreground">Back to sign in</Link>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email"
                required
                className="w-full rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none ring-ring/30 focus:ring-2"
              />
              <button type="submit" disabled={busy} className="w-full rounded-2xl bg-brand py-3 text-sm font-semibold text-primary-foreground shadow-soft disabled:opacity-60">
                {busy ? "Sending…" : "Send reset link"}
              </button>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}
