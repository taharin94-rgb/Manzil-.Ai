import { useEffect, useMemo, useRef, useState } from "react";
import panduRam from "@/assets/pandu-ram.png";
import type { VideoSlide } from "@/lib/career-video.functions";

export type Lang = "hi" | "en" | "hg" | "mr" | "ta" | "te" | "bn" | "gu" | "kn" | "ml" | "pa";

const LANG_LABEL: Record<Lang, string> = {
  hi: "हिंदी", en: "English", hg: "Hinglish",
  mr: "मराठी", ta: "தமிழ்", te: "తెలుగు", bn: "বাংলা", gu: "ગુજરાતી", kn: "ಕನ್ನಡ", ml: "മലയാളം", pa: "ਪੰਜਾਬੀ",
};
const LANG_ORDER: Lang[] = ["hi", "en", "hg", "mr", "ta", "te", "bn", "gu", "kn", "ml", "pa"];

export function CareerVideoPlayer({
  careerName, slides, onRequestTranslation, translatingLang,
}: {
  careerName: string;
  slides: VideoSlide[];
  onRequestTranslation?: (lang: Lang) => void;
  translatingLang?: Lang | null;
}) {
  const [lang, setLang] = useState<Lang>("hi");
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [talking, setTalking] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  const playingRef = useRef(playing);
  playingRef.current = playing;
  const desiredLangRef = useRef<Lang | null>(null);

  const total = slides.length;
  const current = slides[index];

  useEffect(() => {
    // Preload voices (Chrome loads them async on first call).
    window.speechSynthesis.getVoices();
  }, []);

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [playing]);

  const LOCALE: Record<Lang, string> = {
    hi: "hi-IN", en: "en-IN", hg: "hi-IN",
    mr: "mr-IN", ta: "ta-IN", te: "te-IN", bn: "bn-IN", gu: "gu-IN", kn: "kn-IN", ml: "ml-IN", pa: "pa-IN",
  };

  function pickVoice() {
    const voices = window.speechSynthesis.getVoices();
    const target = LOCALE[lang];
    return (
      voices.find((v) => v.lang?.toLowerCase() === target.toLowerCase()) ??
      voices.find((v) => v.lang?.toLowerCase().startsWith(target.slice(0, 2))) ??
      voices.find((v) => v.lang?.toLowerCase().startsWith("hi")) ??
      voices.find((v) => v.lang?.toLowerCase().startsWith("en-in")) ??
      voices[0]
    );
  }

  function speak(i: number, autoAdvance: boolean) {
    window.speechSynthesis.cancel();
    if (i < 0 || i >= total) {
      setPlaying(false);
      setTalking(false);
      return;
    }
    setIndex(i);
    const slide = slides[i];
    const content = slide[lang] ?? slide.hi ?? slide.en;
    const utter = new SpeechSynthesisUtterance(content.text);
    const v = pickVoice();
    if (v) utter.voice = v;
    utter.lang = v?.lang ?? LOCALE[lang];
    utter.rate = 0.98;
    utter.pitch = 1.02;
    utter.onstart = () => setTalking(true);
    utter.onend = () => {
      setTalking(false);
      if (autoAdvance && playingRef.current) speak(i + 1, true);
    };
    utter.onerror = () => {
      setTalking(false);
      setPlaying(false);
    };
    window.speechSynthesis.speak(utter);
  }

  function togglePlay() {
    if (playing) {
      playingRef.current = false;
      window.speechSynthesis.cancel();
      setPlaying(false);
      setTalking(false);
    } else {
      playingRef.current = true;
      setPlaying(true);
      speak(index >= total ? 0 : index, true);
    }
  }

  function goTo(i: number, autoSpeak: boolean) {
    const clamped = Math.max(0, Math.min(total - 1, i));
    if (autoSpeak && playing) {
      playingRef.current = true;
      speak(clamped, true);
    } else {
      window.speechSynthesis.cancel();
      setTalking(false);
      setIndex(clamped);
    }
  }

  function restart() {
    playingRef.current = false;
    window.speechSynthesis.cancel();
    setPlaying(false);
    setTalking(false);
    setIndex(0);
    setSeconds(0);
  }

  function changeLang(next: Lang) {
    const hasIt = Boolean(slides[0]?.[next]);
    if (!hasIt) {
      desiredLangRef.current = next;
      onRequestTranslation?.(next);
      return;
    }
    const wasPlaying = playing;
    window.speechSynthesis.cancel();
    setTalking(false);
    setLang(next);
    if (wasPlaying) {
      playingRef.current = true;
      setPlaying(true);
      setTimeout(() => speak(index, true), 0);
    }
  }

  useEffect(() => {
    if (desiredLangRef.current && slides[0]?.[desiredLangRef.current]) {
      const next = desiredLangRef.current;
      desiredLangRef.current = null;
      setLang(next);
    }
  }, [slides]);

  function seekToRatio(ratio: number) {
    const i = Math.min(total - 1, Math.max(0, Math.floor(ratio * total)));
    goTo(i, true);
  }

  const seekTrackRef = useRef<HTMLDivElement>(null);
  function handleSeekPointer(clientX: number) {
    const rect = seekTrackRef.current?.getBoundingClientRect();
    if (!rect) return;
    seekToRatio((clientX - rect.left) / rect.width);
  }

  function handleTouchStart(e: React.TouchEvent) {
    touchStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }
  function handleTouchEnd(e: React.TouchEvent) {
    if (!touchStart.current) return;
    const dx = e.changedTouches[0].clientX - touchStart.current.x;
    const dy = e.changedTouches[0].clientY - touchStart.current.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) goTo(index + 1, true);
      else goTo(index - 1, true);
    }
    touchStart.current = null;
  }

  useEffect(() => () => window.speechSynthesis.cancel(), []);

  const progressPct = ((index) / total) * 100;
  const timeLabel = useMemo(() => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  }, [seconds]);

  const content = current[lang] ?? current.hi ?? current.en;

  return (
    <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
      {/* header */}
      <div className="bg-brand px-3 py-2.5 text-primary-foreground">
        <div className="flex items-center gap-2">
          <span className="text-lg">🎬</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{careerName}</p>
            <p className="text-[10.5px] opacity-85">AI Career Video</p>
          </div>
        </div>
        <div className="mt-2 flex gap-1 overflow-x-auto rounded-full bg-white/15 p-0.5" style={{ scrollbarWidth: "none" }}>
          {LANG_ORDER.map((l) => (
            <button
              key={l}
              onClick={() => changeLang(l)}
              disabled={translatingLang === l}
              className={`shrink-0 rounded-full px-2.5 py-1 text-[10.5px] font-semibold transition-colors ${lang === l ? "bg-white text-brand" : "text-white/75"}`}
            >
              {translatingLang === l ? "⏳" : LANG_LABEL[l]}
            </button>
          ))}
        </div>
      </div>
      {translatingLang && (
        <p className="bg-accent/10 px-3 py-1.5 text-center text-[10.5px] text-accent">{LANG_LABEL[translatingLang]} mein translate ho raha hai…</p>
      )}

      {/* stage */}
      <div
        className="relative flex aspect-[4/5] items-center justify-center overflow-hidden"
        style={{ background: "linear-gradient(160deg, #2A2340 0%, #4A3B72 55%, #6B4F8F 100%)" }}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <span className="absolute left-3 top-3 z-10 rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white">
          {index + 1} / {total}
        </span>
        <span className="absolute right-3 top-3 z-10 rounded-full bg-white/10 px-2 py-1 text-[9.5px] text-white/70">← स्वाइप करें →</span>

        <div className="relative flex items-center justify-center">
          <div className={`video-ring ring-1 ${talking ? "is-playing" : ""}`} />
          <div className={`video-ring ring-2 ${talking ? "is-playing" : ""}`} />
          <div className={`video-ring ring-3 ${talking ? "is-playing" : ""}`} />
          <img
            src={panduRam}
            alt="Pandu Ram"
            className={`video-pandu-img relative z-10 h-32 w-32 object-contain drop-shadow-[0_12px_22px_rgba(0,0,0,0.35)] ${talking ? "is-talking" : ""}`}
          />
        </div>

        <div className="absolute inset-x-3 bottom-3 z-10 max-h-[46%] overflow-hidden rounded-2xl bg-white/95 px-4 py-3 text-center">
          <div className="mb-1 text-2xl">{current.icon}</div>
          {current.stat ? (
            <>
              <p className="font-display text-xl font-bold text-brand">{current.stat}</p>
              <p className="text-[10.5px] font-semibold text-muted-foreground">{content.label}</p>
            </>
          ) : (
            <h3 className="font-display text-sm font-semibold">{content.title}</h3>
          )}
          <p className="mt-1 text-[11px] leading-snug text-muted-foreground">{content.caption}</p>
        </div>
      </div>

      {/* caption / transcript */}
      <div className="min-h-[46px] px-4 pt-3">
        <p className="text-[13px] leading-relaxed">{playing || index > 0 ? content.text : "▶️ Play दबाकर शुरू करें"}</p>
      </div>

      {/* seek bar */}
      <div className="px-4 pt-2">
        <div
          ref={seekTrackRef}
          className="relative flex h-3 cursor-pointer items-center"
          onMouseDown={(e) => handleSeekPointer(e.clientX)}
          onTouchStart={(e) => handleSeekPointer(e.touches[0].clientX)}
          onTouchMove={(e) => handleSeekPointer(e.touches[0].clientX)}
        >
          <div className="absolute inset-x-0 h-1 rounded-full bg-border" />
          <div className="absolute h-1 rounded-full bg-brand" style={{ width: `${progressPct}%` }} />
          {slides.map((_, i) => (
            <div key={i} className="absolute h-2 w-0.5 -translate-x-1/2 rounded bg-white/70" style={{ left: `${(i / total) * 100}%` }} />
          ))}
          <div
            className="absolute h-3 w-3 -translate-x-1/2 rounded-full border-2 border-brand bg-white shadow"
            style={{ left: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* controls */}
      <div className="flex items-center justify-center gap-3 px-4 py-3">
        <span className="w-8 text-[10.5px] tabular-nums text-muted-foreground">{timeLabel}</span>
        <button onClick={restart} className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card-soft text-sm">↺</button>
        <button onClick={() => goTo(index - 1, true)} className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card-soft text-sm">⏮</button>
        <button onClick={togglePlay} className="grid h-12 w-12 place-items-center rounded-full bg-brand text-lg text-primary-foreground shadow-pop">
          {playing ? "⏸" : "▶"}
        </button>
        <button onClick={() => goTo(index + 1, true)} className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card-soft text-sm">⏭</button>
        <span className="w-8 text-right text-[10.5px] tabular-nums text-muted-foreground">~5:00</span>
      </div>
      <p className="pb-3 text-center text-[10.5px] text-muted-foreground">
        {playing ? `बोल रहा है... (${index + 1}/${total})` : index >= total - 1 && seconds > 0 ? "पूरा हो गया — फिर से सुनने के लिए ↺ दबाएं" : "Ready"}
      </p>
    </div>
  );
}
