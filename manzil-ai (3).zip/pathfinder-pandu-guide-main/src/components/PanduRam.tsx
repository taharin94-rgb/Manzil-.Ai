import panduRam from "@/assets/pandu-ram.png";

export function PanduRam({ className = "h-24 w-24", priority = false }: { className?: string; priority?: boolean }) {
  return (
    <img
      src={panduRam}
      alt="Mr. Pandu Ram, your AI career mentor"
      width={1024}
      height={1024}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      className={className + " select-none drop-shadow-[0_8px_24px_rgba(124,58,237,0.25)]"}
    />
  );
}
