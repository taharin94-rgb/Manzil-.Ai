import { Component, type ReactNode } from "react";

export class VideoErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error: unknown) {
    console.error("[CareerVideoPlayer] crashed, showing fallback:", error);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="py-4 text-center">
          <p className="text-xs text-muted-foreground">Video load nahi ho paayi is baar — baaki jaankari neeche dekh sakte ho.</p>
        </div>
      );
    }
    return this.props.children;
  }
}
