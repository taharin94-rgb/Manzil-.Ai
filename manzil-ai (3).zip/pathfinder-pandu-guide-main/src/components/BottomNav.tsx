import { Link, useLocation } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Home, MessageCircle, Compass, Target, Crown, Swords, Sparkle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { navLabel } from "@/lib/i18n";

const items = [
  { to: "/dashboard", icon: Home, label: "Home" },
  { to: "/explore", icon: Compass, label: "Explore" },
  { to: "/chat", icon: MessageCircle, label: "Mentor" },
  { to: "/roadmap", icon: Target, label: "Goals" },
  { to: "/battle", icon: Swords, label: "Battle" },
  { to: "/prediction", icon: Sparkle, label: "Predict" },
  { to: "/pricing", icon: Crown, label: "Premium" },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  const { data: lang } = useQuery({
    queryKey: ["nav-language"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return "English";
      const { data } = await supabase.from("profiles").select("language").eq("id", user.id).maybeSingle();
      return data?.language ?? "English";
    },
    staleTime: 30_000,
  });

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <ul className="mx-auto flex max-w-md items-center justify-around px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2">
        {items.map(({ to, icon: Icon, label }) => {
          const active = pathname === to || pathname.startsWith(to + "/");
          return (
            <li key={to} className="flex-1">
              <Link to={to} className={"flex flex-col items-center gap-1 rounded-2xl px-2 py-1.5 text-[11px] font-medium transition " + (active ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
                <Icon className={"h-5 w-5 " + (active ? "stroke-[2.5]" : "")} />
                {navLabel(label, lang)}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
