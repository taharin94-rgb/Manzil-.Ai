-- Cache table for AI-generated "career video" scripts (used by the
-- career detail page's video player). Kept separate from `careers`
-- (which is admin-write-only) so any logged-in student's request can
-- cache a freshly-generated script without needing admin RLS access.
-- The script itself is non-sensitive, shared content (same script for
-- every student who views a given career), so read/insert is open to
-- all authenticated users.

CREATE TABLE public.career_videos (
  career_slug text PRIMARY KEY REFERENCES public.careers(slug) ON DELETE CASCADE,
  script jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.career_videos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated can read cached career videos"
  ON public.career_videos FOR SELECT TO authenticated USING (true);

CREATE POLICY "authenticated can cache a career video"
  ON public.career_videos FOR INSERT TO authenticated WITH CHECK (true);
