-- Cache table for AI-generated career future-demand predictions.
-- Mirrors career_videos: non-sensitive shared content, cached once per
-- career so repeated views don't re-trigger AI calls.

CREATE TABLE public.career_predictions (
  career_slug text PRIMARY KEY REFERENCES public.careers(slug) ON DELETE CASCADE,
  prediction jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.career_predictions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated can read cached predictions"
  ON public.career_predictions FOR SELECT TO authenticated USING (true);

CREATE POLICY "authenticated can cache a prediction"
  ON public.career_predictions FOR INSERT TO authenticated WITH CHECK (true);
