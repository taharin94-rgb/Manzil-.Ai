-- Lightweight daily-streak tracker. Kept as its own tiny table (not a
-- profiles column) so it's isolated and can't affect any existing data.

CREATE TABLE public.user_streaks (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  streak_count integer NOT NULL DEFAULT 1,
  last_active_date date NOT NULL DEFAULT current_date
);

ALTER TABLE public.user_streaks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own streak read"
  ON public.user_streaks FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "own streak upsert"
  ON public.user_streaks FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own streak update"
  ON public.user_streaks FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
