
-- 1. ROLES
CREATE TYPE public.app_role AS ENUM ('student', 'parent', 'school', 'admin');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "view own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- Default every new user to 'student'
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'student')
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created_role
  AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_role();

-- 2. INVITE CODES (student generates, parent/school redeems)
CREATE TABLE public.invite_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  intended_role public.app_role NOT NULL CHECK (intended_role IN ('parent','school')),
  used_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.invite_codes TO authenticated;
GRANT ALL ON public.invite_codes TO service_role;
ALTER TABLE public.invite_codes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "student manages own codes" ON public.invite_codes FOR ALL TO authenticated
  USING (auth.uid() = student_id) WITH CHECK (auth.uid() = student_id);
CREATE POLICY "anyone signed in can redeem" ON public.invite_codes FOR UPDATE TO authenticated
  USING (used_by IS NULL) WITH CHECK (used_by = auth.uid());

-- 3. LINKS
CREATE TABLE public.parent_students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(parent_id, student_id)
);
GRANT SELECT, INSERT, DELETE ON public.parent_students TO authenticated;
GRANT ALL ON public.parent_students TO service_role;
ALTER TABLE public.parent_students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "parent sees own links" ON public.parent_students FOR SELECT TO authenticated
  USING (auth.uid() = parent_id OR auth.uid() = student_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "parent inserts own link" ON public.parent_students FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = parent_id);
CREATE POLICY "parent removes own link" ON public.parent_students FOR DELETE TO authenticated
  USING (auth.uid() = parent_id OR auth.uid() = student_id);

CREATE TABLE public.school_students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(school_id, student_id)
);
GRANT SELECT, INSERT, DELETE ON public.school_students TO authenticated;
GRANT ALL ON public.school_students TO service_role;
ALTER TABLE public.school_students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "school sees own links" ON public.school_students FOR SELECT TO authenticated
  USING (auth.uid() = school_id OR auth.uid() = student_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "school inserts own link" ON public.school_students FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = school_id);
CREATE POLICY "school removes own link" ON public.school_students FOR DELETE TO authenticated
  USING (auth.uid() = school_id OR auth.uid() = student_id);

-- Helper: is _viewer linked to _student?
CREATE OR REPLACE FUNCTION public.can_view_student(_viewer uuid, _student uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT _viewer = _student
      OR EXISTS (SELECT 1 FROM public.parent_students WHERE parent_id = _viewer AND student_id = _student)
      OR EXISTS (SELECT 1 FROM public.school_students WHERE school_id = _viewer AND student_id = _student)
      OR public.has_role(_viewer, 'admin')
$$;

-- Extend existing tables so linked viewers can read
CREATE POLICY "linked viewers read profiles" ON public.profiles FOR SELECT TO authenticated
  USING (public.can_view_student(auth.uid(), id));
CREATE POLICY "linked viewers read assessments" ON public.assessments FOR SELECT TO authenticated
  USING (public.can_view_student(auth.uid(), user_id));
CREATE POLICY "linked viewers read goals" ON public.goals FOR SELECT TO authenticated
  USING (public.can_view_student(auth.uid(), user_id));

-- 4. SUBSCRIPTIONS
CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free' CHECK (plan IN ('free','premium_monthly','premium_yearly')),
  status text NOT NULL DEFAULT 'active',
  stripe_customer_id text,
  stripe_subscription_id text,
  current_period_end timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view own sub" ON public.subscriptions FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER tg_subscriptions_updated BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

CREATE OR REPLACE FUNCTION public.is_premium(_user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.subscriptions
    WHERE user_id = _user AND plan <> 'free' AND status = 'active'
      AND (current_period_end IS NULL OR current_period_end > now())
  )
$$;

-- 5. CAREERS CONTENT
CREATE TABLE public.careers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  category text NOT NULL,
  name text NOT NULL,
  tagline text,
  overview text,
  skills jsonb NOT NULL DEFAULT '[]',
  salary jsonb NOT NULL DEFAULT '{}',
  growth text,
  roadmap jsonb NOT NULL DEFAULT '[]',
  emoji text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.careers TO anon, authenticated;
GRANT ALL ON public.careers TO service_role;
ALTER TABLE public.careers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "careers public read" ON public.careers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin manages careers" ON public.careers FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER tg_careers_updated BEFORE UPDATE ON public.careers
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- Seed 8 categories
INSERT INTO public.careers (slug, category, name, tagline, overview, skills, salary, growth, roadmap, emoji) VALUES
('engineering','Engineering','Engineering','Build the future — from chips to skyscrapers.',
 'Engineering applies science and math to design, build, and improve systems that solve real-world problems. Branches include Computer Science, Mechanical, Electrical, Civil, and more.',
 '["Mathematics","Problem solving","Coding (CS branches)","CAD / design tools","Teamwork"]'::jsonb,
 '{"entry":"₹4–8 LPA","mid":"₹10–25 LPA","senior":"₹30–80 LPA+"}'::jsonb,
 'Massive demand in tech, EV, semiconductors, renewable energy and infrastructure.',
 '[{"step":"Class 11–12 PCM"},{"step":"Crack JEE Main / Advanced or state CET"},{"step":"B.Tech (4 years) from IIT/NIT/IIIT/State"},{"step":"Internships + projects"},{"step":"Job / M.Tech / MS abroad"}]'::jsonb,'⚙️'),
('medical','Medical','Medical & Healthcare','Heal, care, save lives.',
 'Doctors, surgeons, dentists, physiotherapists and allied health roles. Long training, deeply respected, high earning ceiling.',
 '["Biology & Chemistry","Empathy","Stamina","Long-term focus","Communication"]'::jsonb,
 '{"entry":"₹6–12 LPA","mid":"₹15–40 LPA","senior":"₹50 LPA – ₹2 Cr+"}'::jsonb,
 'India has a doctor shortage; demand is strong across cities and rural areas.',
 '[{"step":"Class 11–12 PCB"},{"step":"Crack NEET-UG"},{"step":"MBBS (5.5 yrs)"},{"step":"NEET-PG → MD/MS specialization"},{"step":"Practice / Hospital / Super-specialty"}]'::jsonb,'🩺'),
('commerce','Commerce','Commerce & Finance','Numbers run the world.',
 'CA, CFA, investment banking, FinTech, accounting, business analytics. Strong fit for analytical minds who love money and markets.',
 '["Math","Logical reasoning","Excel/Tally","Attention to detail","Business sense"]'::jsonb,
 '{"entry":"₹4–10 LPA","mid":"₹12–30 LPA","senior":"₹40 LPA – ₹1 Cr+"}'::jsonb,
 'India''s financial sector and startups are booming — CA + tech is a power combo.',
 '[{"step":"Class 11–12 Commerce"},{"step":"CA Foundation / B.Com / BBA"},{"step":"CA Intermediate / CFA L1"},{"step":"Articleship / Internship"},{"step":"CA Final / MBA / Job"}]'::jsonb,'📊'),
('law','Law','Law & Public Policy','Argue, advise, shape society.',
 'Lawyers, corporate counsel, judges, policy analysts. Great fit for those who love debate, reading, and reasoning.',
 '["English","Logical reasoning","Reading comprehension","Public speaking","Research"]'::jsonb,
 '{"entry":"₹5–12 LPA","mid":"₹15–40 LPA","senior":"₹50 LPA – ₹5 Cr+"}'::jsonb,
 'Corporate law, IP, and tech law are growing fast as the economy formalises.',
 '[{"step":"Class 11–12 (any stream)"},{"step":"Crack CLAT / AILET"},{"step":"5-year integrated BA LLB at NLU"},{"step":"Internships at law firms"},{"step":"Litigation / corporate / judiciary"}]'::jsonb,'⚖️'),
('design','Design','Design & Creative Arts','Make things beautiful and useful.',
 'UI/UX, product design, fashion, animation, architecture. Where art meets problem-solving.',
 '["Sketching","Visual thinking","Software (Figma/Adobe)","Curiosity","Storytelling"]'::jsonb,
 '{"entry":"₹4–9 LPA","mid":"₹12–25 LPA","senior":"₹30–60 LPA+"}'::jsonb,
 'Every tech product needs designers; India''s creator economy is exploding.',
 '[{"step":"Class 11–12 (any stream)"},{"step":"Build a portfolio"},{"step":"Crack UCEED / NID DAT / NIFT"},{"step":"B.Des (4 yrs) at NID/IIT/NIFT/Srishti"},{"step":"Internships → product/agency/freelance"}]'::jsonb,'🎨'),
('government','Government Jobs','Government & Civil Services','Serve the nation.',
 'IAS, IPS, IFS, banking PO, SSC, defence. Stable, prestigious, with real-world impact.',
 '["General knowledge","Current affairs","Writing","Discipline","Patience"]'::jsonb,
 '{"entry":"₹7–12 LPA","mid":"₹15–25 LPA","senior":"₹30 LPA + perks"}'::jsonb,
 'Lakhs of vacancies every year; clearing UPSC/SSC is competitive but life-changing.',
 '[{"step":"Graduation (any)"},{"step":"Start prep alongside college"},{"step":"UPSC/SSC/Banking/State PSC exams"},{"step":"Interview"},{"step":"Training + posting"}]'::jsonb,'🏛️'),
('ai_tech','AI & Technology','AI & Technology','Build the brains of tomorrow.',
 'AI/ML engineers, data scientists, cybersecurity, blockchain, cloud. Fastest-growing field globally.',
 '["Math (linear algebra, stats)","Python","Machine learning","Curiosity","Continuous learning"]'::jsonb,
 '{"entry":"₹6–15 LPA","mid":"₹20–50 LPA","senior":"₹60 LPA – ₹3 Cr+"}'::jsonb,
 'Every industry is hiring AI talent — salaries are among the highest in tech.',
 '[{"step":"Class 11–12 PCM (or strong CS)"},{"step":"B.Tech CS / AI / Data Science"},{"step":"Online specializations (Coursera/fast.ai)"},{"step":"Build projects + Kaggle"},{"step":"AI engineer / researcher / MS"}]'::jsonb,'🤖'),
('entrepreneurship','Entrepreneurship','Entrepreneurship','Build your own thing.',
 'Founders, indie hackers, family business, D2C brands. No degree required — only relentless execution.',
 '["Hustle","Communication","Basic finance","Product thinking","Resilience"]'::jsonb,
 '{"entry":"Variable","mid":"₹10 LPA – Crores","senior":"Unbounded"}'::jsonb,
 'India is the world''s 3rd largest startup ecosystem. Funding, mentors, and customers are all here.',
 '[{"step":"Build skills (any stream)"},{"step":"Start a small project / side hustle"},{"step":"College + internship at a startup"},{"step":"Find a co-founder, validate an idea"},{"step":"Launch → revenue → raise or bootstrap"}]'::jsonb,'🚀');
