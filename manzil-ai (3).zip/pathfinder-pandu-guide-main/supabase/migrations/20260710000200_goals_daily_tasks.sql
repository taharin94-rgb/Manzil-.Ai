-- Small, rotating "today's task" list per goal — separate from the big
-- roadmap milestones (e.g. "Complete Class 10"). These are specific,
-- actionable micro-tasks like "Learn Python variables & loops today"
-- that students can actually do in a session, tied to their chosen career.

ALTER TABLE public.goals ADD COLUMN daily_tasks jsonb NOT NULL DEFAULT '[]'::jsonb;
